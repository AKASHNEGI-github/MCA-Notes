-- TaskFlow - reference data (roles, permissions, role -> permission mapping).
-- Safe to run repeatedly (INSERT IGNORE on unique keys).
-- The first admin user is created by `npm run db:init` (see backend/scripts/init-db.js)
-- because it needs a bcrypt hash.

INSERT IGNORE INTO roles (name, scope, description) VALUES
  ('ADMIN',   'GLOBAL',  'Full access: manages users, roles and every project'),
  ('MANAGER', 'GLOBAL',  'Can create projects and becomes their owner'),
  ('MEMBER',  'GLOBAL',  'Default role: works on projects they are added to'),
  ('OWNER',   'PROJECT', 'Full control of a project'),
  ('EDITOR',  'PROJECT', 'Creates tasks and updates tasks they own'),
  ('VIEWER',  'PROJECT', 'Read-only access to a project');

INSERT IGNORE INTO permissions (code, scope, description) VALUES
  ('user:read',          'GLOBAL',  'View all users'),
  ('user:create',        'GLOBAL',  'Create users'),
  ('user:update',        'GLOBAL',  'Edit users'),
  ('user:delete',        'GLOBAL',  'Delete users'),
  ('user:assign-role',   'GLOBAL',  'Change a user''s global role'),
  ('project:create',     'GLOBAL',  'Create projects'),
  ('project:read-all',   'GLOBAL',  'See and open every project'),
  ('audit:read-all',     'GLOBAL',  'View the system-wide audit log'),
  ('project:read',       'PROJECT', 'View the project'),
  ('project:update',     'PROJECT', 'Edit or archive the project'),
  ('project:delete',     'PROJECT', 'Delete the project'),
  ('project:manage-members', 'PROJECT', 'Add, remove and change members'),
  ('task:read',          'PROJECT', 'View tasks'),
  ('task:create',        'PROJECT', 'Create tasks'),
  ('task:update',        'PROJECT', 'Update any task'),
  ('task:update-own',    'PROJECT', 'Update tasks created by or assigned to you'),
  ('task:delete',        'PROJECT', 'Delete tasks'),
  ('comment:read',       'PROJECT', 'View comments'),
  ('comment:create',     'PROJECT', 'Write comments'),
  ('comment:delete',     'PROJECT', 'Delete anyone''s comment'),
  ('audit:read',         'PROJECT', 'View the project activity feed');

-- ADMIN gets every GLOBAL permission, OWNER gets every PROJECT permission.
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
JOIN permissions p ON p.scope = r.scope
WHERE (r.scope = 'GLOBAL' AND r.name = 'ADMIN')
   OR (r.scope = 'PROJECT' AND r.name = 'OWNER');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM (
  SELECT 'GLOBAL'  AS scope, 'MANAGER' AS role_name, 'project:create' AS code
  UNION ALL SELECT 'PROJECT', 'EDITOR', 'project:read'
  UNION ALL SELECT 'PROJECT', 'EDITOR', 'task:read'
  UNION ALL SELECT 'PROJECT', 'EDITOR', 'task:create'
  UNION ALL SELECT 'PROJECT', 'EDITOR', 'task:update-own'
  UNION ALL SELECT 'PROJECT', 'EDITOR', 'comment:read'
  UNION ALL SELECT 'PROJECT', 'EDITOR', 'comment:create'
  UNION ALL SELECT 'PROJECT', 'VIEWER', 'project:read'
  UNION ALL SELECT 'PROJECT', 'VIEWER', 'task:read'
  UNION ALL SELECT 'PROJECT', 'VIEWER', 'comment:read'
) m
JOIN roles r       ON r.scope = m.scope AND r.name = m.role_name
JOIN permissions p ON p.code = m.code;
