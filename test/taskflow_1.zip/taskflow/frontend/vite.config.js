import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    plugins: [react(), tailwindcss()],
    server: {
      port: 5173,
      // Browser calls /api/... and Vite forwards it to the Express server (no CORS needed in dev).
      proxy: { '/api': { target: env.VITE_API_PROXY_TARGET || 'http://localhost:4000', changeOrigin: true } },
    },
  };
});
