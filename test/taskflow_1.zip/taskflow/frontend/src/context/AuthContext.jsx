import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { get, post, tokenStore } from '../lib/api';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(Boolean(tokenStore.access || tokenStore.refresh));

  // Restore the session on first load.
  useEffect(() => {
    let cancelled = false;
    if (!tokenStore.access && !tokenStore.refresh) return undefined;
    get('/auth/me')
      .then((res) => !cancelled && setUser(res.data))
      .catch(() => !cancelled && setUser(null))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
  }, []);

  // The API client fires this when the session can no longer be refreshed.
  useEffect(() => {
    const onLogout = () => setUser(null);
    window.addEventListener('auth:logout', onLogout);
    return () => window.removeEventListener('auth:logout', onLogout);
  }, []);

  const startSession = useCallback((data) => {
    tokenStore.set(data);
    setUser(data.user);
  }, []);

  const login = useCallback(async (credentials) => startSession((await post('/auth/login', credentials)).data), [startSession]);
  const register = useCallback(async (details) => startSession((await post('/auth/register', details)).data), [startSession]);

  const logout = useCallback(async () => {
    const refreshToken = tokenStore.refresh;
    try {
      if (refreshToken) await post('/auth/logout', { refreshToken });
    } catch { /* signing out locally is enough */ }
    tokenStore.clear();
    setUser(null);
  }, []);

  const refreshUser = useCallback(async () => setUser((await get('/auth/me')).data), []);

  const value = useMemo(
    () => ({
      user,
      loading,
      login,
      register,
      logout,
      refreshUser,
      startSession,
      can: (permission) => Boolean(user?.permissions?.includes(permission)),
    }),
    [user, loading, login, register, logout, refreshUser, startSession]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
