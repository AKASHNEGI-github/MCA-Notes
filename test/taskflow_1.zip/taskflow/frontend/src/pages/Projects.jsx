import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FolderKanban, Plus, Search } from 'lucide-react';
import { get, post } from '../lib/api';
import { useFetch } from '../hooks/useFetch';
import { useDebounce } from '../hooks/useDebounce';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PERM } from '../lib/constants';
import { Button, Card, EmptyState, ErrorState, Input, Modal, PageHeader, PageLoader, Pagination, Select } from '../components/ui';
import ProjectCard from '../components/projects/ProjectCard';
import ProjectForm from '../components/projects/ProjectForm';

export default function Projects() {
  const { can } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(false);
  const debounced = useDebounce(search);

  const { data, meta, loading, error, reload } = useFetch(() => get('/projects', { page, limit: 9, search: debounced, status }), [page, debounced, status]);

  const create = async (values) => {
    const res = await post('/projects', values);
    toast.success('Project created');
    setCreating(false);
    navigate(`/projects/${res.data.id}`);
  };

  return (
    <div>
      <PageHeader
        title="Projects"
        description="Everything you can work on, in one place."
        actions={can(PERM.PROJECT_CREATE) && <Button icon={Plus} onClick={() => setCreating(true)}>New project</Button>}
      />

      <div className="mb-5 flex flex-wrap gap-2">
        <div className="relative min-w-[220px] max-w-sm flex-1">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-subtle" />
          <Input className="pl-9" placeholder="Search projects" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} aria-label="Search projects" />
        </div>
        <Select className="w-[150px]" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} aria-label="Filter by status">
          <option value="">All projects</option>
          <option value="ACTIVE">Active</option>
          <option value="ARCHIVED">Archived</option>
        </Select>
      </div>

      {loading && !data ? (
        <PageLoader />
      ) : error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : data.length === 0 ? (
        <Card>
          <EmptyState
            icon={FolderKanban}
            title={debounced || status ? 'No projects match' : 'No projects yet'}
            description={debounced || status ? 'Try a different search or filter.' : can(PERM.PROJECT_CREATE) ? 'Create your first project to start adding tasks.' : 'You will see projects here once an owner adds you.'}
            action={!debounced && !status && can(PERM.PROJECT_CREATE) ? <Button icon={Plus} onClick={() => setCreating(true)}>New project</Button> : null}
          />
        </Card>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{data.map((p) => <ProjectCard key={p.id} project={p} />)}</div>
          <Card className="mt-5"><Pagination meta={meta} onPage={setPage} /></Card>
        </>
      )}

      {creating && (
        <Modal title="New project" description="You will be its owner and can add people afterwards." onClose={() => setCreating(false)}>
          <ProjectForm submitLabel="Create project" onSubmit={create} onCancel={() => setCreating(false)} />
        </Modal>
      )}
    </div>
  );
}
