import { useState } from 'react';
import { get } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { Card, ErrorState, PageLoader, Pagination } from '../../components/ui';
import ActivityList from '../../components/tasks/ActivityList';

export default function ActivityTab({ project, refreshKey }) {
  const [page, setPage] = useState(1);
  const { data, meta, loading, error, reload } = useFetch(() => get(`/projects/${project.id}/activity`, { page, limit: 20 }), [project.id, page, refreshKey]);
  if (loading && !data) return <PageLoader />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  return (
    <Card>
      <ActivityList logs={data} />
      <Pagination meta={meta} onPage={setPage} />
    </Card>
  );
}
