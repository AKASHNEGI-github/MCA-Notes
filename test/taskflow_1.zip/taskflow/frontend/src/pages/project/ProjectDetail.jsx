import { useCallback, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Archive, ChevronLeft } from 'lucide-react';
import { get } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { ErrorState, PageLoader, RoleBadge, Tabs } from '../../components/ui';
import TaskDrawer from '../../components/tasks/TaskDrawer';
import OverviewTab from './OverviewTab';
import TasksTab from './TasksTab';
import MembersTab from './MembersTab';
import ActivityTab from './ActivityTab';
import SettingsTab from './SettingsTab';

export default function ProjectDetail() {
  const { projectId } = useParams();
  const [params, setParams] = useSearchParams();
  const [refreshKey, setRefreshKey] = useState(0); // bumps when tasks change so other tabs refetch
  const [creating, setCreating] = useState(false);

  const { data: project, loading, error, reload } = useFetch(() => get(`/projects/${projectId}`), [projectId, refreshKey]);
  const { data: members, reload: reloadMembers } = useFetch(() => get(`/projects/${projectId}/members`), [projectId]);

  const tab = params.get('tab') || 'tasks';
  const openTaskId = params.get('task') ? Number(params.get('task')) : null;
  const bump = useCallback(() => setRefreshKey((k) => k + 1), []);

  const setTab = (value) => setParams({ tab: value }, { replace: true });
  const openTask = (id) => setParams({ tab, task: String(id) }, { replace: true });
  const closeDrawer = () => { setCreating(false); setParams({ tab }, { replace: true }); };

  if (loading && !project) return <PageLoader />;
  if (error || !project) return <ErrorState message={error ?? 'Project not found'} onRetry={reload} />;

  const can = (p) => project.permissions.includes(p);
  const tabs = [
    { value: 'tasks', label: 'Tasks', count: project.taskCount },
    { value: 'overview', label: 'Overview' },
    { value: 'members', label: 'Members', count: project.memberCount },
    ...(can('audit:read') ? [{ value: 'activity', label: 'Activity' }] : []),
    ...(can('project:update') || can('project:delete') ? [{ value: 'settings', label: 'Settings' }] : []),
  ];
  const memberList = members ?? [];

  return (
    <div>
      <Link to="/projects" className="mb-3 inline-flex items-center gap-1 text-[13px] font-semibold text-muted hover:text-ink">
        <ChevronLeft size={15} /> Projects
      </Link>

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <h1 className="text-[22px] font-bold tracking-tight">{project.name}</h1>
        <RoleBadge role={project.myRole} />
      </div>

      {project.status === 'ARCHIVED' && (
        <div className="mb-4 flex items-center gap-2 rounded-control bg-warning-soft px-3 py-2 text-sm text-warning">
          <Archive size={16} /> This project is archived and read-only.
        </div>
      )}

      <Tabs tabs={tabs} value={tab} onChange={setTab} />

      <div className="pt-5">
        {tab === 'tasks' && <TasksTab project={project} members={memberList} refreshKey={refreshKey} onOpenTask={openTask} onCreate={() => setCreating(true)} onChanged={bump} />}
        {tab === 'overview' && <OverviewTab project={project} refreshKey={refreshKey} />}
        {tab === 'members' && <MembersTab project={project} members={memberList} reloadMembers={reloadMembers} onChanged={bump} />}
        {tab === 'activity' && can('audit:read') && <ActivityTab project={project} refreshKey={refreshKey} />}
        {tab === 'settings' && <SettingsTab project={project} onUpdated={bump} />}
      </div>

      {(creating || openTaskId) && (
        <TaskDrawer
          key={creating ? 'new' : openTaskId}
          project={project}
          taskId={creating ? null : openTaskId}
          members={memberList}
          onClose={closeDrawer}
          onChanged={bump}
        />
      )}
    </div>
  );
}
