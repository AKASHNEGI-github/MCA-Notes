import { useState } from 'react';
import { UserPlus, UserX } from 'lucide-react';
import { del, get, getErrorMessage, post, put } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { useDebounce } from '../../hooks/useDebounce';
import { useToast } from '../../context/ToastContext';
import { Avatar, Button, Card, ConfirmDialog, IconButton, Input, RoleBadge, Select } from '../../components/ui';

function AddMember({ project, members, roles, onAdded }) {
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [userId, setUserId] = useState('');
  const [roleId, setRoleId] = useState('');
  const [saving, setSaving] = useState(false);
  const debounced = useDebounce(search);

  const { data: people } = useFetch(() => get('/users/directory', { search: debounced, limit: 50 }), [debounced]);
  const memberIds = new Set(members.map((m) => m.userId));
  const candidates = (people ?? []).filter((p) => !memberIds.has(p.id));
  const defaultRole = roles.find((r) => r.name === 'EDITOR')?.id ?? roles[0]?.id;

  const add = async () => {
    setSaving(true);
    try {
      await post(`/projects/${project.id}/members`, { userId: Number(userId), roleId: Number(roleId || defaultRole) });
      toast.success('Member added');
      setUserId('');
      setSearch('');
      onAdded();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-wrap items-end gap-2 border-b border-line p-3">
      <div className="min-w-[180px] flex-1"><Input placeholder="Search people by name or email" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search people" /></div>
      <Select className="min-w-[200px] flex-1" value={userId} onChange={(e) => setUserId(e.target.value)} aria-label="Person to add">
        <option value="">{candidates.length ? 'Choose a person' : 'No one to add'}</option>
        {candidates.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.email})</option>)}
      </Select>
      <Select className="w-[130px]" value={roleId || defaultRole || ''} onChange={(e) => setRoleId(e.target.value)} aria-label="Project role">
        {roles.map((r) => <option key={r.id} value={r.id}>{r.name.charAt(0) + r.name.slice(1).toLowerCase()}</option>)}
      </Select>
      <Button icon={UserPlus} onClick={add} disabled={!userId} loading={saving}>Add</Button>
    </div>
  );
}

export default function MembersTab({ project, members, reloadMembers, onChanged }) {
  const toast = useToast();
  const { data: roles } = useFetch(() => get('/projects/roles'), []);
  const [removing, setRemoving] = useState(null);
  const canManage = project.permissions.includes('project:manage-members') && project.status !== 'ARCHIVED';

  const changeRole = async (member, roleId) => {
    try {
      await put(`/projects/${project.id}/members/${member.userId}`, { roleId: Number(roleId) });
      toast.success(`${member.name} is now ${roles.find((r) => r.id === Number(roleId))?.name.toLowerCase()}`);
      await reloadMembers();
    } catch (err) {
      toast.error(getErrorMessage(err));
      await reloadMembers();
    }
  };

  const remove = async () => {
    try {
      await del(`/projects/${project.id}/members/${removing.userId}`);
      toast.success('Member removed');
      setRemoving(null);
      await reloadMembers();
      onChanged();
    } catch (err) {
      toast.error(getErrorMessage(err));
      setRemoving(null);
    }
  };

  return (
    <Card>
      {canManage && roles && <AddMember project={project} members={members} roles={roles} onAdded={async () => { await reloadMembers(); onChanged(); }} />}
      <ul className="divide-y divide-line">
        {members.map((m) => (
          <li key={m.userId} className="flex flex-wrap items-center gap-3 px-4 py-3">
            <Avatar name={m.name} size={36} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{m.name}</p>
              <p className="truncate text-xs text-muted">{m.email} · {m.openTasks} open {m.openTasks === 1 ? 'task' : 'tasks'}</p>
            </div>
            {canManage && roles ? (
              <Select size="sm" className="w-[120px]" value={m.role.id} onChange={(e) => changeRole(m, e.target.value)} aria-label={`Role of ${m.name}`}>
                {roles.map((r) => <option key={r.id} value={r.id}>{r.name.charAt(0) + r.name.slice(1).toLowerCase()}</option>)}
              </Select>
            ) : (
              <RoleBadge role={m.role.name} />
            )}
            {canManage && <IconButton icon={UserX} label={`Remove ${m.name}`} onClick={() => setRemoving(m)} />}
          </li>
        ))}
      </ul>
      {removing && (
        <ConfirmDialog
          title={`Remove ${removing.name}?`}
          message="They lose access to this project and their open tasks become unassigned. You can add them again later."
          confirmLabel="Remove member"
          danger
          onConfirm={remove}
          onClose={() => setRemoving(null)}
        />
      )}
    </Card>
  );
}
