import { get } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { PRIORITIES, STATUSES } from '../../lib/constants';
import { cn, formatDate } from '../../lib/format';
import { Avatar, Card, ErrorState, PageLoader, ProgressBar } from '../../components/ui';

const BAR_TONE = { neutral: 'bg-line-strong', info: 'bg-info', warning: 'bg-warning', success: 'bg-success', danger: 'bg-danger' };

function Stat({ label, value, tone }) {
  return (
    <Card className="p-4">
      <p className="text-xs font-semibold text-muted">{label}</p>
      <p className={cn('mt-1 text-2xl font-bold tracking-tight', tone)}>{value}</p>
    </Card>
  );
}

function Breakdown({ title, rows, total }) {
  return (
    <Card className="p-5">
      <h3 className="mb-4 text-sm font-bold">{title}</h3>
      <div className="space-y-3">
        {rows.map((r) => (
          <div key={r.value}>
            <div className="mb-1 flex justify-between text-[13px]">
              <span className="font-medium">{r.label}</span>
              <span className="text-muted">{r.count}</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-sunken">
              <div className={cn('h-full rounded-full', BAR_TONE[r.tone])} style={{ width: `${total ? (r.count / total) * 100 : 0}%` }} />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

export default function OverviewTab({ project, refreshKey }) {
  const { data, loading, error, reload } = useFetch(() => get(`/dashboard/projects/${project.id}`), [project.id, refreshKey]);
  if (loading && !data) return <PageLoader />;
  if (error) return <ErrorState message={error} onRetry={reload} />;

  return (
    <div className="space-y-5">
      <Card className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-bold">Progress</h3>
          <span className="text-sm font-semibold text-primary">{data.completionPercent}% complete</span>
        </div>
        <ProgressBar value={data.completionPercent} className="mt-3 h-2.5" />
        <p className="mt-3 text-sm text-muted">
          {project.description || 'No description yet.'}
        </p>
        <p className="mt-2 text-xs text-subtle">
          {project.startDate || project.endDate ? `${formatDate(project.startDate)} to ${formatDate(project.endDate)}` : 'No dates set'}
        </p>
      </Card>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total tasks" value={data.total} />
        <Stat label="Overdue" value={data.overdue} tone={data.overdue ? 'text-danger' : undefined} />
        <Stat label="Unassigned" value={data.unassigned} tone={data.unassigned ? 'text-warning' : undefined} />
        <Stat label="Members" value={data.members} />
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Breakdown title="By status" total={data.total} rows={STATUSES.map((s) => ({ ...s, count: data.byStatus[s.value] ?? 0 }))} />
        <Breakdown title="By priority" total={data.total} rows={PRIORITIES.map((p) => ({ ...p, count: data.byPriority[p.value] ?? 0 }))} />
        <Card className="p-5">
          <h3 className="mb-4 text-sm font-bold">Open work by person</h3>
          {data.workload.length === 0 ? (
            <p className="text-sm text-muted">No open tasks are assigned yet.</p>
          ) : (
            <ul className="space-y-3">
              {data.workload.map((w) => (
                <li key={w.userId} className="flex items-center gap-3 text-sm">
                  <Avatar name={w.name} size={26} />
                  <span className="flex-1 truncate font-medium">{w.name}</span>
                  <span className="text-muted">{w.openTasks} open</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
