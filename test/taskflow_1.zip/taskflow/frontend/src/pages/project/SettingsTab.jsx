import { useState } from 'react';
import { Archive, ArchiveRestore, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { del, getErrorMessage, put } from '../../lib/api';
import { useToast } from '../../context/ToastContext';
import { Button, Card, ConfirmDialog } from '../../components/ui';
import ProjectForm from '../../components/projects/ProjectForm';

export default function SettingsTab({ project, onUpdated }) {
  const toast = useToast();
  const navigate = useNavigate();
  const [confirm, setConfirm] = useState(null); // 'archive' | 'delete'
  const [busy, setBusy] = useState(false);
  const canUpdate = project.permissions.includes('project:update');
  const canDelete = project.permissions.includes('project:delete');
  const archived = project.status === 'ARCHIVED';

  const save = async (values) => {
    await put(`/projects/${project.id}`, values);
    toast.success('Project saved');
    onUpdated();
  };

  const toggleArchive = async () => {
    setBusy(true);
    try {
      await put(`/projects/${project.id}`, { status: archived ? 'ACTIVE' : 'ARCHIVED' });
      toast.success(archived ? 'Project restored' : 'Project archived');
      setConfirm(null);
      onUpdated();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await del(`/projects/${project.id}`);
      toast.success('Project deleted');
      navigate('/projects', { replace: true });
    } catch (err) {
      toast.error(getErrorMessage(err));
      setBusy(false);
      setConfirm(null);
    }
  };

  return (
    <div className="max-w-2xl space-y-5">
      <Card className="p-5">
        <h3 className="mb-4 text-sm font-bold">Project details</h3>
        {canUpdate ? (
          <>
            <ProjectForm id="project-settings" initial={project} onSubmit={save} />
            <div className="mt-4 flex justify-end"><Button type="submit" form="project-settings">Save changes</Button></div>
          </>
        ) : (
          <p className="text-sm text-muted">Only project owners can edit these details.</p>
        )}
      </Card>

      {(canUpdate || canDelete) && (
        <Card className="p-5">
          <h3 className="mb-1 text-sm font-bold">{archived ? 'Archived project' : 'Archive or delete'}</h3>
          <p className="mb-4 text-sm text-muted">
            {archived ? 'Archived projects are read-only. Restore it to keep working.' : 'Archiving makes the project read-only but keeps everything. Deleting removes it and all of its tasks and comments.'}
          </p>
          <div className="flex flex-wrap gap-2">
            {canUpdate && <Button variant="secondary" icon={archived ? ArchiveRestore : Archive} onClick={() => (archived ? toggleArchive() : setConfirm('archive'))} loading={busy && archived}>{archived ? 'Restore project' : 'Archive project'}</Button>}
            {canDelete && <Button variant="danger-soft" icon={Trash2} onClick={() => setConfirm('delete')}>Delete project</Button>}
          </div>
        </Card>
      )}

      {confirm === 'archive' && <ConfirmDialog title="Archive this project?" message="Nobody will be able to add or change tasks, comments or members until you restore it." confirmLabel="Archive project" loading={busy} onConfirm={toggleArchive} onClose={() => setConfirm(null)} />}
      {confirm === 'delete' && <ConfirmDialog title={`Delete "${project.name}"?`} message="This removes the project with all of its tasks, comments and memberships." confirmLabel="Delete project" danger loading={busy} onConfirm={remove} onClose={() => setConfirm(null)} />}
    </div>
  );
}
