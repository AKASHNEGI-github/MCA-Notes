import { useState } from 'react';
import { ListChecks, Plus, Search } from 'lucide-react';
import { get, getErrorMessage, patch } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { useDebounce } from '../../hooks/useDebounce';
import { useToast } from '../../context/ToastContext';
import { PRIORITIES, STATUSES } from '../../lib/constants';
import { Button, Card, EmptyState, ErrorState, Input, PageLoader, Pagination, Select } from '../../components/ui';
import TaskTable from '../../components/tasks/TaskTable';

const SORTS = [
  { value: 'createdAt:desc', label: 'Newest first' },
  { value: 'dueDate:asc', label: 'Due date' },
  { value: 'priority:desc', label: 'Priority' },
  { value: 'status:asc', label: 'Status' },
  { value: 'title:asc', label: 'Title A–Z' },
];

export default function TasksTab({ project, members, refreshKey, onOpenTask, onCreate, onChanged }) {
  const toast = useToast();
  const [filters, setFilters] = useState({ search: '', status: '', priority: '', assignee: '', overdue: false, sort: 'createdAt:desc' });
  const [page, setPage] = useState(1);
  const search = useDebounce(filters.search);

  const [sortBy, sortOrder] = filters.sort.split(':');
  const { data, meta, loading, error, reload } = useFetch(
    () =>
      get(`/projects/${project.id}/tasks`, {
        page,
        limit: 10,
        search,
        status: filters.status,
        priority: filters.priority,
        assigneeId: filters.assignee && filters.assignee !== 'none' ? filters.assignee : undefined,
        unassigned: filters.assignee === 'none' ? 'true' : undefined,
        overdue: filters.overdue ? 'true' : undefined,
        sortBy,
        sortOrder,
      }),
    [project.id, page, search, filters.status, filters.priority, filters.assignee, filters.overdue, filters.sort, refreshKey]
  );

  const update = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setFilters((f) => ({ ...f, [key]: value }));
    setPage(1);
  };

  const changeStatus = async (task, status) => {
    try {
      await patch(`/projects/${project.id}/tasks/${task.id}/status`, { status });
      await reload({ silent: true });
      onChanged();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const archived = project.status === 'ARCHIVED';
  const canCreate = project.permissions.includes('task:create') && !archived;
  const hasFilters = search || filters.status || filters.priority || filters.assignee || filters.overdue;

  return (
    <Card>
      <div className="flex flex-wrap items-center gap-2 border-b border-line p-3">
        <div className="relative min-w-[160px] flex-1">
          <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-subtle" />
          <Input className="pl-9" placeholder="Search tasks" value={filters.search} onChange={update('search')} aria-label="Search tasks" />
        </div>
        <Select className="w-[130px]" value={filters.status} onChange={update('status')} aria-label="Filter by status">
          <option value="">All statuses</option>
          {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </Select>
        <Select className="w-[130px]" value={filters.priority} onChange={update('priority')} aria-label="Filter by priority">
          <option value="">All priorities</option>
          {PRIORITIES.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
        </Select>
        <Select className="w-[140px]" value={filters.assignee} onChange={update('assignee')} aria-label="Filter by assignee">
          <option value="">Anyone</option>
          <option value="none">Unassigned</option>
          {members.map((m) => <option key={m.userId} value={m.userId}>{m.name}</option>)}
        </Select>
        <Select className="w-[130px]" value={filters.sort} onChange={update('sort')} aria-label="Sort tasks">
          {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </Select>
        <label className="flex cursor-pointer items-center gap-2 px-1 text-[13px] font-medium text-muted">
          <input type="checkbox" checked={filters.overdue} onChange={update('overdue')} className="h-4 w-4 accent-[var(--primary)]" />
          Overdue only
        </label>
        {canCreate && <Button icon={Plus} onClick={onCreate} className="ml-auto">New task</Button>}
      </div>

      {loading && !data ? (
        <PageLoader />
      ) : error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : data.length === 0 ? (
        <EmptyState
          icon={ListChecks}
          title={hasFilters ? 'No tasks match these filters' : 'No tasks yet'}
          description={hasFilters ? 'Try clearing a filter or searching for something else.' : canCreate ? 'Create the first task to get this project moving.' : 'Tasks added to this project will appear here.'}
          action={!hasFilters && canCreate ? <Button icon={Plus} onClick={onCreate}>New task</Button> : null}
        />
      ) : (
        <>
          <TaskTable tasks={data} onOpen={(t) => onOpenTask(t.id)} onStatusChange={archived ? undefined : changeStatus} />
          <Pagination meta={meta} onPage={setPage} />
        </>
      )}
    </Card>
  );
}
