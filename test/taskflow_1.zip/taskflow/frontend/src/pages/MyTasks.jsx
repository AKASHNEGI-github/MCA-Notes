import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ListChecks, Search } from 'lucide-react';
import { get } from '../lib/api';
import { useFetch } from '../hooks/useFetch';
import { useDebounce } from '../hooks/useDebounce';
import { PRIORITIES, STATUSES } from '../lib/constants';
import { Card, EmptyState, ErrorState, Input, PageHeader, PageLoader, Pagination, Select } from '../components/ui';
import TaskTable from '../components/tasks/TaskTable';

export default function MyTasks() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState({ search: '', status: '', priority: '', overdue: false, sort: 'dueDate:asc' });
  const [page, setPage] = useState(1);
  const search = useDebounce(filters.search);
  const [sortBy, sortOrder] = filters.sort.split(':');

  const { data, meta, loading, error, reload } = useFetch(
    () => get('/tasks/my', { page, limit: 10, search, status: filters.status, priority: filters.priority, overdue: filters.overdue ? 'true' : undefined, sortBy, sortOrder }),
    [page, search, filters.status, filters.priority, filters.overdue, filters.sort]
  );

  const update = (key) => (e) => {
    setFilters((f) => ({ ...f, [key]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));
    setPage(1);
  };
  const hasFilters = search || filters.status || filters.priority || filters.overdue;

  return (
    <div>
      <PageHeader title="My tasks" description="Everything assigned to you, across all projects." />
      <Card>
        <div className="flex flex-wrap items-center gap-2 border-b border-line p-3">
          <div className="relative min-w-[200px] flex-1">
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-subtle" />
            <Input className="pl-9" placeholder="Search your tasks" value={filters.search} onChange={update('search')} aria-label="Search your tasks" />
          </div>
          <Select className="w-[140px]" value={filters.status} onChange={update('status')} aria-label="Filter by status">
            <option value="">All statuses</option>
            {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </Select>
          <Select className="w-[140px]" value={filters.priority} onChange={update('priority')} aria-label="Filter by priority">
            <option value="">All priorities</option>
            {PRIORITIES.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
          </Select>
          <Select className="w-[140px]" value={filters.sort} onChange={update('sort')} aria-label="Sort tasks">
            <option value="dueDate:asc">Due date</option>
            <option value="priority:desc">Priority</option>
            <option value="createdAt:desc">Newest first</option>
          </Select>
          <label className="flex cursor-pointer items-center gap-2 px-1 text-[13px] font-medium text-muted">
            <input type="checkbox" checked={filters.overdue} onChange={update('overdue')} className="h-4 w-4 accent-[var(--primary)]" /> Overdue only
          </label>
        </div>

        {loading && !data ? <PageLoader /> : error ? <ErrorState message={error} onRetry={reload} /> : data.length === 0 ? (
          <EmptyState icon={ListChecks} title={hasFilters ? 'No tasks match these filters' : 'Nothing assigned to you'} description={hasFilters ? 'Try clearing a filter.' : 'Tasks assigned to you will show up here.'} />
        ) : (
          <>
            <TaskTable tasks={data} showProject onOpen={(t) => navigate(`/projects/${t.projectId}?tab=tasks&task=${t.id}`)} />
            <Pagination meta={meta} onPage={setPage} />
          </>
        )}
      </Card>
    </div>
  );
}
