import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { EmptyState } from '../components/ui';

export default function NotFound() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <EmptyState icon={Compass} title="Page not found" description="The page you are looking for does not exist or has moved." action={<Link to="/" className="text-sm font-semibold text-primary hover:underline">Go to dashboard</Link>} />
    </div>
  );
}
