import { Link } from 'react-router-dom';
import { AlertTriangle, CalendarClock, CheckCircle2, ListChecks, Loader } from 'lucide-react';
import { get } from '../lib/api';
import { useFetch } from '../hooks/useFetch';
import { useAuth } from '../context/AuthContext';
import { cn, formatDate } from '../lib/format';
import { Card, EmptyState, ErrorState, PageHeader, PageLoader, PriorityMark } from '../components/ui';
import ProjectCard from '../components/projects/ProjectCard';

function Stat({ icon: Icon, label, value, tone = 'text-ink', to }) {
  const body = (
    <Card className="flex items-center gap-4 p-4 transition-colors hover:border-line-strong">
      <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-sunken text-muted"><Icon size={20} /></span>
      <div>
        <p className={cn('text-2xl font-bold leading-none tracking-tight', tone)}>{value}</p>
        <p className="mt-1 text-xs font-semibold text-muted">{label}</p>
      </div>
    </Card>
  );
  return to ? <Link to={to}>{body}</Link> : body;
}

function TaskList({ title, tasks, empty, danger }) {
  return (
    <Card>
      <h2 className="border-b border-line px-5 py-3.5 text-sm font-bold">{title}</h2>
      {tasks.length === 0 ? (
        <p className="px-5 py-8 text-center text-sm text-muted">{empty}</p>
      ) : (
        <ul className="divide-y divide-line">
          {tasks.map((t) => (
            <li key={t.id}>
              <Link to={`/projects/${t.projectId}?tab=tasks&task=${t.id}`} className="flex items-center gap-3 px-5 py-3 hover:bg-canvas">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{t.title}</p>
                  <p className="truncate text-xs text-subtle">{t.projectName}</p>
                </div>
                <PriorityMark priority={t.priority} showLabel={false} />
                <span className={cn('w-[84px] shrink-0 text-right text-[13px]', danger ? 'font-semibold text-danger' : 'text-muted')}>{formatDate(t.dueDate)}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { data, loading, error, reload } = useFetch(() => get('/dashboard'), []);

  if (loading && !data) return <PageLoader />;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  const { stats } = data;

  return (
    <div>
      <PageHeader title={`Hello, ${user.name.split(' ')[0]}`} description="Here is what is on your plate." />

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat icon={ListChecks} label="Assigned to you" value={stats.assigned} to="/my-tasks" />
        <Stat icon={Loader} label="In progress" value={stats.inProgress} />
        <Stat icon={CalendarClock} label="Due in 7 days" value={stats.dueSoon} />
        <Stat icon={AlertTriangle} label="Overdue" value={stats.overdue} tone={stats.overdue ? 'text-danger' : 'text-ink'} />
      </div>

      <div className="mb-8 grid gap-5 lg:grid-cols-2">
        <TaskList title="Coming up" tasks={data.upcoming} empty="Nothing is due soon. Nice." />
        <TaskList title="Overdue" tasks={data.overdue} empty="No overdue tasks." danger />
      </div>

      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-base font-bold">Your projects</h2>
        {data.projectCount > data.projects.length && <Link to="/projects" className="text-[13px] font-semibold text-primary hover:underline">View all {data.projectCount}</Link>}
      </div>
      {data.projects.length === 0 ? (
        <Card><EmptyState icon={CheckCircle2} title="You are not in any project yet" description="Ask a project owner to add you, or a manager to create one." /></Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {data.projects.map((p) => <ProjectCard key={p.id} project={p} />)}
        </div>
      )}
    </div>
  );
}
