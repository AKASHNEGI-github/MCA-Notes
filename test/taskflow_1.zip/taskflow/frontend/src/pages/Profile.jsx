import { useState } from 'react';
import { get, getErrorMessage, getFieldErrors, put } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Avatar, Button, Card, Field, FormError, Input, PageHeader, RoleBadge } from '../components/ui';

function ProfileForm() {
  const { user, refreshUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ name: user.name, email: user.email });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErrors({}); setFormError(''); setLoading(true);
    try {
      await put('/users/me', form);
      await refreshUser();
      toast.success('Profile updated');
    } catch (err) {
      setErrors(getFieldErrors(err));
      setFormError(err.response?.status === 422 ? '' : getErrorMessage(err));
    } finally { setLoading(false); }
  };

  return (
    <Card className="p-5">
      <h2 className="mb-4 text-sm font-bold">Your details</h2>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormError message={formError} />
        <Field label="Full name" error={errors.name}><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} error={errors.name} /></Field>
        <Field label="Email" error={errors.email}><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} error={errors.email} /></Field>
        <div className="flex justify-end"><Button type="submit" loading={loading}>Save changes</Button></div>
      </form>
    </Card>
  );
}

function PasswordForm() {
  const { startSession } = useAuth();
  const toast = useToast();
  const empty = { currentPassword: '', newPassword: '', confirm: '' };
  const [form, setForm] = useState(empty);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setFormError('');
    if (form.newPassword !== form.confirm) { setErrors({ confirm: 'Passwords do not match' }); return; }
    setErrors({}); setLoading(true);
    try {
      const res = await put('/auth/change-password', { currentPassword: form.currentPassword, newPassword: form.newPassword });
      startSession(res.data); // the server signed out every other session and issued fresh tokens
      setForm(empty);
      toast.success('Password changed. Other devices were signed out.');
    } catch (err) {
      setErrors(getFieldErrors(err));
      setFormError(err.response?.status === 422 ? '' : getErrorMessage(err));
    } finally { setLoading(false); }
  };

  return (
    <Card className="p-5">
      <h2 className="mb-4 text-sm font-bold">Change password</h2>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormError message={formError} />
        <Field label="Current password" error={errors.currentPassword}><Input type="password" autoComplete="current-password" value={form.currentPassword} onChange={set('currentPassword')} error={errors.currentPassword} /></Field>
        <Field label="New password" error={errors.newPassword} hint="At least 8 characters, with a letter and a number."><Input type="password" autoComplete="new-password" value={form.newPassword} onChange={set('newPassword')} error={errors.newPassword} /></Field>
        <Field label="Confirm new password" error={errors.confirm}><Input type="password" autoComplete="new-password" value={form.confirm} onChange={set('confirm')} error={errors.confirm} /></Field>
        <div className="flex justify-end"><Button type="submit" loading={loading}>Update password</Button></div>
      </form>
    </Card>
  );
}

export default function Profile() {
  const { user } = useAuth();
  return (
    <div className="max-w-2xl">
      <PageHeader title="Profile" />
      <div className="mb-5 flex items-center gap-4">
        <Avatar name={user.name} size={56} />
        <div>
          <p className="text-base font-bold">{user.name}</p>
          <p className="text-sm text-muted">{user.email}</p>
          <div className="mt-1"><RoleBadge role={user.role.name} /></div>
        </div>
      </div>
      <div className="space-y-5"><ProfileForm /><PasswordForm /></div>
    </div>
  );
}
