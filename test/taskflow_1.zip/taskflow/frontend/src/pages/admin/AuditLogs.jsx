import { useState } from 'react';
import { get } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { Card, ErrorState, PageHeader, PageLoader, Pagination, Select } from '../../components/ui';
import ActivityList from '../../components/tasks/ActivityList';

const ENTITIES = [
  { value: '', label: 'Everything' },
  { value: 'AUTH', label: 'Sign-ins' },
  { value: 'USER', label: 'Users' },
  { value: 'PROJECT', label: 'Projects' },
  { value: 'MEMBER', label: 'Members' },
  { value: 'TASK', label: 'Tasks and comments' },
];

export default function AuditLogs() {
  const [entityType, setEntityType] = useState('');
  const [page, setPage] = useState(1);
  const { data, meta, loading, error, reload } = useFetch(() => get('/admin/audit-logs', { page, limit: 25, entityType }), [page, entityType]);

  return (
    <div>
      <PageHeader title="Audit log" description="Every change made in the system, who made it and when." />
      <Card>
        <div className="border-b border-line p-3">
          <Select className="w-[220px]" value={entityType} onChange={(e) => { setEntityType(e.target.value); setPage(1); }} aria-label="Filter by area">
            {ENTITIES.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </Select>
        </div>
        {loading && !data ? <PageLoader /> : error ? <ErrorState message={error} onRetry={reload} /> : (
          <>
            <ActivityList logs={data} showProject />
            <Pagination meta={meta} onPage={setPage} />
          </>
        )}
      </Card>
    </div>
  );
}
