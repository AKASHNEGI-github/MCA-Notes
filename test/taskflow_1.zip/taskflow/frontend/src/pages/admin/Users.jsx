import { useState } from 'react';
import { Pencil, Plus, Search, Trash2, Users as UsersIcon } from 'lucide-react';
import { del, get, getErrorMessage, getFieldErrors, post, put } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { useDebounce } from '../../hooks/useDebounce';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { PERM } from '../../lib/constants';
import { formatDateTime } from '../../lib/format';
import { Avatar, Badge, Button, Card, ConfirmDialog, EmptyState, ErrorState, Field, FormError, IconButton, Input, Modal, PageHeader, PageLoader, Pagination, Select } from '../../components/ui';

const roleLabel = (n) => n.charAt(0) + n.slice(1).toLowerCase();

function UserFormModal({ user, roles, onClose, onSaved }) {
  const toast = useToast();
  const isNew = !user;
  const memberRole = roles.find((r) => r.name === 'MEMBER')?.id ?? roles[0]?.id;
  const [form, setForm] = useState({ name: user?.name ?? '', email: user?.email ?? '', password: '', roleId: user?.role.id ?? memberRole, isActive: user?.isActive ?? true });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setErrors({}); setFormError(''); setLoading(true);
    try {
      if (isNew) {
        await post('/admin/users', { name: form.name, email: form.email, password: form.password, roleId: Number(form.roleId) });
        toast.success('User created');
      } else {
        await put(`/admin/users/${user.id}`, { name: form.name, email: form.email, isActive: form.isActive });
        toast.success('User updated');
      }
      onSaved();
    } catch (err) {
      setErrors(getFieldErrors(err));
      setFormError(err.response?.status === 422 ? '' : getErrorMessage(err));
    } finally { setLoading(false); }
  };

  return (
    <Modal title={isNew ? 'Add user' : 'Edit user'} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4" noValidate>
        <FormError message={formError} />
        <Field label="Full name" error={errors.name}><Input value={form.name} onChange={set('name')} error={errors.name} autoFocus /></Field>
        <Field label="Email" error={errors.email}><Input type="email" value={form.email} onChange={set('email')} error={errors.email} /></Field>
        {isNew && (
          <>
            <Field label="Temporary password" error={errors.password} hint="At least 8 characters, with a letter and a number."><Input type="password" value={form.password} onChange={set('password')} error={errors.password} autoComplete="new-password" /></Field>
            <Field label="Role" error={errors.roleId}>
              <Select value={form.roleId} onChange={set('roleId')}>{roles.map((r) => <option key={r.id} value={r.id}>{roleLabel(r.name)}</option>)}</Select>
            </Field>
          </>
        )}
        {!isNew && (
          <label className="flex cursor-pointer items-center gap-2 text-sm font-medium">
            <input type="checkbox" checked={form.isActive} onChange={set('isActive')} className="h-4 w-4 accent-[var(--primary)]" />
            Account is active (inactive users cannot sign in)
          </label>
        )}
        <div className="flex justify-end gap-2 pt-1">
          <Button variant="secondary" onClick={onClose} disabled={loading}>Cancel</Button>
          <Button type="submit" loading={loading}>{isNew ? 'Add user' : 'Save changes'}</Button>
        </div>
      </form>
    </Modal>
  );
}

export default function Users() {
  const { user: me, can } = useAuth();
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [roleId, setRoleId] = useState('');
  const [active, setActive] = useState('');
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState(undefined); // undefined = closed, null = new, object = edit
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);
  const debounced = useDebounce(search);

  const { data: roles } = useFetch(() => get('/admin/roles', { scope: 'GLOBAL' }), []);
  const { data, meta, loading, error, reload } = useFetch(
    () => get('/admin/users', { page, limit: 10, search: debounced, roleId, isActive: active }),
    [page, debounced, roleId, active]
  );

  const reset = (setter) => (e) => { setter(e.target.value); setPage(1); };

  const changeRole = async (u, newRoleId) => {
    try {
      await put(`/admin/users/${u.id}/role`, { roleId: Number(newRoleId) });
      toast.success(`${u.name}'s role was updated`);
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
    reload({ silent: true });
  };

  const remove = async () => {
    setBusy(true);
    try {
      await del(`/admin/users/${deleting.id}`);
      toast.success('User deleted');
      setDeleting(null);
      reload({ silent: true });
    } catch (err) {
      toast.error(getErrorMessage(err));
      setDeleting(null);
    } finally { setBusy(false); }
  };

  return (
    <div>
      <PageHeader title="Users" description="Create accounts, set global roles and deactivate access." actions={can(PERM.USER_CREATE) && roles && <Button icon={Plus} onClick={() => setEditing(null)}>Add user</Button>} />

      <Card>
        <div className="flex flex-wrap items-center gap-2 border-b border-line p-3">
          <div className="relative min-w-[200px] flex-1">
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-subtle" />
            <Input className="pl-9" placeholder="Search by name or email" value={search} onChange={reset(setSearch)} aria-label="Search users" />
          </div>
          <Select className="w-[150px]" value={roleId} onChange={reset(setRoleId)} aria-label="Filter by role">
            <option value="">All roles</option>
            {(roles ?? []).map((r) => <option key={r.id} value={r.id}>{roleLabel(r.name)}</option>)}
          </Select>
          <Select className="w-[150px]" value={active} onChange={reset(setActive)} aria-label="Filter by status">
            <option value="">Any status</option>
            <option value="true">Active</option>
            <option value="false">Inactive</option>
          </Select>
        </div>

        {loading && !data ? <PageLoader /> : error ? <ErrorState message={error} onRetry={reload} /> : data.length === 0 ? (
          <EmptyState icon={UsersIcon} title="No users found" description="Try a different search or filter." />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-sm">
                <thead>
                  <tr className="border-b border-line text-xs font-semibold text-muted">
                    <th className="px-4 py-2.5">User</th><th className="px-3 py-2.5">Role</th><th className="px-3 py-2.5">Status</th><th className="px-3 py-2.5">Last sign-in</th><th className="px-3 py-2.5" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {data.map((u) => {
                    const self = u.id === me.id;
                    return (
                      <tr key={u.id}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <Avatar name={u.name} size={34} />
                            <div className="min-w-0"><p className="truncate font-semibold">{u.name}{self && <span className="ml-2 text-xs font-medium text-subtle">(you)</span>}</p><p className="truncate text-xs text-muted">{u.email}</p></div>
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          {can(PERM.USER_ASSIGN_ROLE) && !self && roles ? (
                            <Select size="sm" className="w-[120px]" value={u.role.id} onChange={(e) => changeRole(u, e.target.value)} aria-label={`Role of ${u.name}`}>
                              {roles.map((r) => <option key={r.id} value={r.id}>{roleLabel(r.name)}</option>)}
                            </Select>
                          ) : <Badge tone="primary">{roleLabel(u.role.name)}</Badge>}
                        </td>
                        <td className="px-3 py-3">{u.isActive ? <Badge tone="success">Active</Badge> : <Badge>Inactive</Badge>}</td>
                        <td className="whitespace-nowrap px-3 py-3 text-muted">{u.lastLoginAt ? formatDateTime(u.lastLoginAt) : 'Never'}</td>
                        <td className="px-3 py-3">
                          <div className="flex justify-end">
                            {can(PERM.USER_UPDATE) && <IconButton icon={Pencil} label={`Edit ${u.name}`} onClick={() => setEditing(u)} />}
                            {can(PERM.USER_DELETE) && !self && <IconButton icon={Trash2} label={`Delete ${u.name}`} onClick={() => setDeleting(u)} />}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination meta={meta} onPage={setPage} />
          </>
        )}
      </Card>

      {editing !== undefined && roles && <UserFormModal user={editing} roles={roles} onClose={() => setEditing(undefined)} onSaved={() => { setEditing(undefined); reload({ silent: true }); }} />}
      {deleting && <ConfirmDialog title={`Delete ${deleting.name}?`} message="They will be signed out and lose access. Their past activity stays in the audit log. Users who are the only owner of a project cannot be deleted." confirmLabel="Delete user" danger loading={busy} onConfirm={remove} onClose={() => setDeleting(null)} />}
    </div>
  );
}
