import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Info } from 'lucide-react';
import { Button, Field, Input } from '../../components/ui';
import AuthShell from './AuthShell';

/**
 * UI only for now: the reset flow has not been built on the backend yet, so submitting
 * never calls the API. When the flow exists, replace `submit` with the real request.
 */
export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    if (email.trim()) setSubmitted(true);
  };

  return (
    <AuthShell
      title="Reset your password"
      subtitle="Enter the email you signed up with."
      footer={<Link to="/login" className="inline-flex items-center gap-1.5 font-semibold text-primary hover:underline"><ArrowLeft size={14} /> Back to sign in</Link>}
    >
      {submitted ? (
        <div role="status" className="flex gap-3 rounded-control bg-info-soft p-4 text-sm text-info">
          <Info size={18} className="mt-0.5 shrink-0" />
          <p>Password reset is not available yet. Please contact your administrator to get back into your account.</p>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4" noValidate>
          <Field label="Email">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" autoComplete="email" autoFocus />
          </Field>
          <Button type="submit" className="w-full">Send reset link</Button>
        </form>
      )}
    </AuthShell>
  );
}
