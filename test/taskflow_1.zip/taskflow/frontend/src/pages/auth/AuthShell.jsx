import { ListChecks } from 'lucide-react';
import { Avatar, PriorityMark } from '../../components/ui';

const BOARD = [
  { title: 'To do', cards: [{ t: 'Draft launch checklist', p: 'HIGH', who: 'Maya Chen' }, { t: 'Review pricing copy', p: 'LOW', who: 'Leo Park' }] },
  { title: 'In progress', cards: [{ t: 'Design onboarding flow', p: 'URGENT', who: 'Ana Silva' }, { t: 'Set up CI pipeline', p: 'MEDIUM', who: 'Maya Chen' }] },
  { title: 'Done', cards: [{ t: 'Choose project name', p: 'LOW', who: 'Leo Park' }] },
];

function BoardPreview() {
  return (
    <div className="grid grid-cols-3 gap-3" aria-hidden>
      {BOARD.map((col) => (
        <div key={col.title} className="rounded-panel bg-white/10 p-2.5">
          <p className="mb-2 px-1 text-xs font-semibold text-white/80">{col.title}</p>
          <div className="space-y-2">
            {col.cards.map((c) => (
              <div key={c.t} className="rounded-lg bg-surface p-2.5 text-ink shadow-panel">
                <p className="text-[12.5px] font-semibold leading-snug">{c.t}</p>
                <div className="mt-2 flex items-center justify-between">
                  <PriorityMark priority={c.p} showLabel={false} />
                  <Avatar name={c.who} size={20} />
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function AuthShell({ title, subtitle, children, footer }) {
  return (
    <div className="grid min-h-full lg:grid-cols-[1.05fr_1fr]">
      <section className="hidden flex-col justify-between bg-primary p-12 text-on-primary lg:flex">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/15"><ListChecks size={20} /></span>
          <span className="text-lg font-bold tracking-tight">TaskFlow</span>
        </div>
        <div className="max-w-xl">
          <h2 className="mb-3 text-[34px] font-bold leading-[1.15] tracking-tight">Plan the work. Assign it. See it through.</h2>
          <p className="mb-8 max-w-md text-[15px] text-white/80">Projects, tasks and comments in one place, with the right access for every person on the team.</p>
          <BoardPreview />
        </div>
        <p className="text-xs text-white/60">Owners, editors and viewers each see exactly what they need.</p>
      </section>

      <section className="flex items-center justify-center px-5 py-10 sm:px-10">
        <div className="w-full max-w-[400px]">
          <div className="mb-8 flex items-center gap-2.5 lg:hidden">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-on-primary"><ListChecks size={18} /></span>
            <span className="text-[17px] font-bold">TaskFlow</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
          <p className="mb-7 mt-1.5 text-sm text-muted">{subtitle}</p>
          {children}
          <div className="mt-6 text-center text-sm text-muted">{footer}</div>
        </div>
      </section>
    </div>
  );
}
