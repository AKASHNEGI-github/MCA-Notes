import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { PERM } from './lib/constants';
import AppLayout from './components/layout/AppLayout';
import { ProtectedRoute, PublicOnlyRoute, RequirePermission } from './components/layout/RouteGuards';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import ForgotPassword from './pages/auth/ForgotPassword';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import ProjectDetail from './pages/project/ProjectDetail';
import MyTasks from './pages/MyTasks';
import Profile from './pages/Profile';
import Users from './pages/admin/Users';
import AuditLogs from './pages/admin/AuditLogs';
import NotFound from './pages/NotFound';

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <Routes>
            <Route element={<PublicOnlyRoute />}>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
            </Route>

            <Route element={<ProtectedRoute />}>
              <Route element={<AppLayout />}>
                <Route index element={<Dashboard />} />
                <Route path="projects" element={<Projects />} />
                <Route path="projects/:projectId" element={<ProjectDetail />} />
                <Route path="my-tasks" element={<MyTasks />} />
                <Route path="profile" element={<Profile />} />
                <Route path="admin/users" element={<RequirePermission permission={PERM.USER_READ}><Users /></RequirePermission>} />
                <Route path="admin/audit-logs" element={<RequirePermission permission={PERM.AUDIT_READ_ALL}><AuditLogs /></RequirePermission>} />
                <Route path="*" element={<NotFound />} />
              </Route>
            </Route>
          </Routes>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
