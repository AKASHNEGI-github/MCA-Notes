import { useState } from 'react';
import { getErrorMessage, getFieldErrors } from '../../lib/api';
import { Button, Field, FormError, Input, Textarea } from '../ui';

/** Create / edit form shared by the "New project" modal and the Settings tab. */
export default function ProjectForm({ initial = {}, submitLabel = 'Save', onSubmit, onCancel, id }) {
  const [form, setForm] = useState({
    name: initial.name ?? '',
    description: initial.description ?? '',
    startDate: initial.startDate ?? '',
    endDate: initial.endDate ?? '',
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setErrors({});
    setFormError('');
    setLoading(true);
    try {
      await onSubmit({
        name: form.name,
        description: form.description.trim() || null,
        startDate: form.startDate || null,
        endDate: form.endDate || null,
      });
    } catch (err) {
      setErrors(getFieldErrors(err));
      setFormError(err.response?.status === 422 ? '' : getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <form id={id} onSubmit={submit} className="space-y-4" noValidate>
      <FormError message={formError} />
      <Field label="Project name" error={errors.name}>
        <Input value={form.name} onChange={set('name')} error={errors.name} placeholder="Website redesign" autoFocus />
      </Field>
      <Field label="Description" error={errors.description}>
        <Textarea value={form.description} onChange={set('description')} error={errors.description} rows={3} placeholder="What is this project about?" />
      </Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Start date" error={errors.startDate}><Input type="date" value={form.startDate} onChange={set('startDate')} error={errors.startDate} /></Field>
        <Field label="End date" error={errors.endDate}><Input type="date" value={form.endDate} onChange={set('endDate')} error={errors.endDate} /></Field>
      </div>
      {!id && (
        <div className="flex justify-end gap-2 pt-1">
          {onCancel && <Button variant="secondary" onClick={onCancel} disabled={loading}>Cancel</Button>}
          <Button type="submit" loading={loading}>{submitLabel}</Button>
        </div>
      )}
    </form>
  );
}
