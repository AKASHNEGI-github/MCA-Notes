import { Link } from 'react-router-dom';
import { Archive, CheckCircle2, Users } from 'lucide-react';
import { percent } from '../../lib/format';
import { Badge, Card, ProgressBar, RoleBadge } from '../ui';

export default function ProjectCard({ project }) {
  const progress = percent(project.doneCount, project.taskCount);
  return (
    <Link to={`/projects/${project.id}`} className="block h-full rounded-panel focus-visible:outline-offset-4">
      <Card className="flex h-full flex-col p-5 transition-colors hover:border-line-strong">
        <div className="mb-2 flex items-start justify-between gap-3">
          <h3 className="line-clamp-2 text-[15px] font-bold leading-snug">{project.name}</h3>
          {project.status === 'ARCHIVED' ? <Badge><Archive size={12} /> Archived</Badge> : <RoleBadge role={project.myRole} />}
        </div>
        <p className="mb-4 line-clamp-2 min-h-[2.5rem] text-[13px] text-muted">{project.description || 'No description'}</p>
        <div className="mt-auto">
          <div className="mb-1.5 flex justify-between text-xs text-muted">
            <span className="inline-flex items-center gap-1"><CheckCircle2 size={13} /> {project.doneCount}/{project.taskCount} done</span>
            <span className="inline-flex items-center gap-1"><Users size={13} /> {project.memberCount}</span>
          </div>
          <ProgressBar value={progress} />
        </div>
      </Card>
    </Link>
  );
}
