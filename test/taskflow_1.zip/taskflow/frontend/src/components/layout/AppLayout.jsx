import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { FolderKanban, LayoutDashboard, ListChecks, LogOut, Menu, ScrollText, ShieldCheck, UserCircle, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { PERM } from '../../lib/constants';
import { cn } from '../../lib/format';
import { Avatar, RoleBadge } from '../ui';

function NavItem({ to, icon: Icon, label, end, onNavigate }) {
  return (
    <NavLink
      to={to}
      end={end}
      onClick={onNavigate}
      className={({ isActive }) =>
        cn(
          'flex items-center gap-3 rounded-control px-3 py-2 text-sm font-semibold transition-colors',
          isActive ? 'bg-primary-soft text-primary' : 'text-muted hover:bg-sunken hover:text-ink'
        )
      }
    >
      <Icon size={18} />
      {label}
    </NavLink>
  );
}

export default function AppLayout() {
  const { user, can, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  const handleLogout = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-on-primary"><ListChecks size={18} /></span>
        <span className="text-[17px] font-bold tracking-tight">TaskFlow</span>
      </div>

      <nav className="flex-1 space-y-1 px-3" aria-label="Main">
        <NavItem to="/" end icon={LayoutDashboard} label="Dashboard" onNavigate={close} />
        <NavItem to="/projects" icon={FolderKanban} label="Projects" onNavigate={close} />
        <NavItem to="/my-tasks" icon={ListChecks} label="My tasks" onNavigate={close} />

        {(can(PERM.USER_READ) || can(PERM.AUDIT_READ_ALL)) && (
          <>
            <p className="px-3 pb-1 pt-5 text-xs font-semibold text-subtle">Administration</p>
            {can(PERM.USER_READ) && <NavItem to="/admin/users" icon={ShieldCheck} label="Users" onNavigate={close} />}
            {can(PERM.AUDIT_READ_ALL) && <NavItem to="/admin/audit-logs" icon={ScrollText} label="Audit log" onNavigate={close} />}
          </>
        )}
      </nav>

      <div className="border-t border-line p-3">
        <NavLink to="/profile" onClick={close} className="flex items-center gap-3 rounded-control p-2 hover:bg-sunken">
          <Avatar name={user.name} size={34} />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-sm font-semibold">{user.name}</span>
            <span className="mt-0.5 block"><RoleBadge role={user.role.name} /></span>
          </span>
        </NavLink>
        <button onClick={handleLogout} className="mt-1 flex w-full items-center gap-3 rounded-control px-3 py-2 text-sm font-semibold text-muted hover:bg-sunken hover:text-ink">
          <LogOut size={18} /> Sign out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-full">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-line bg-surface lg:block">{sidebar}</aside>

      {open && (
        <div className="anim-fade-in fixed inset-0 z-40 bg-ink/40 lg:hidden" onClick={close}>
          <aside className="anim-slide-in h-full w-64 bg-surface" onClick={(e) => e.stopPropagation()}>{sidebar}</aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col lg:pl-60">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-line bg-surface px-4 py-2.5 lg:hidden">
          <button onClick={() => setOpen((o) => !o)} aria-label="Toggle navigation" className="rounded-control p-1.5 text-ink hover:bg-sunken">
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
          <span className="text-[15px] font-bold">TaskFlow</span>
          <Avatar name={user.name} size={30} />
        </header>

        <main className="mx-auto w-full max-w-[1180px] flex-1 px-4 py-6 sm:px-8 sm:py-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
