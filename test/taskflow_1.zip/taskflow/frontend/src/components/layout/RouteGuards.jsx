import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { EmptyState, PageLoader } from '../ui';

/** Everything inside requires a signed-in user. */
export function ProtectedRoute() {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <div className="pt-24"><PageLoader /></div>;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  return <Outlet />;
}

/** Login / register pages bounce signed-in users to the dashboard. */
export function PublicOnlyRoute() {
  const { user, loading } = useAuth();
  if (loading) return <div className="pt-24"><PageLoader /></div>;
  if (user) return <Navigate to="/" replace />;
  return <Outlet />;
}

/** UI-level permission gate (the API enforces the same rule - this just hides dead ends). */
export function RequirePermission({ permission, children }) {
  const { can } = useAuth();
  if (!can(permission)) {
    return <EmptyState icon={ShieldAlert} title="You do not have access to this page" description="Ask an administrator if you need it." />;
  }
  return children;
}
