import { MessageSquare } from 'lucide-react';
import { PriorityMark, Person, Select, StatusBadge } from '../ui';
import { STATUSES } from '../../lib/constants';
import { cn, formatDate } from '../../lib/format';

/** One table used by the project task list and "My tasks". */
export default function TaskTable({ tasks, onOpen, showProject = false, onStatusChange }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[760px] text-left text-sm">
        <thead>
          <tr className="border-b border-line text-xs font-semibold text-muted">
            <th className="px-4 py-2.5">Task</th>
            <th className="px-3 py-2.5">Status</th>
            <th className="px-3 py-2.5">Priority</th>
            <th className="px-3 py-2.5">Assignee</th>
            <th className="px-3 py-2.5">Due</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {tasks.map((t) => (
            <tr key={t.id} className="cursor-pointer transition-colors hover:bg-canvas" onClick={() => onOpen(t)}>
              <td className="max-w-[340px] px-4 py-3">
                <button className="block max-w-full truncate text-left font-semibold text-ink hover:text-primary" onClick={(e) => { e.stopPropagation(); onOpen(t); }}>
                  {t.title}
                </button>
                <span className="mt-0.5 flex items-center gap-3 text-xs text-subtle">
                  {showProject && <span className="truncate">{t.projectName}</span>}
                  {t.commentCount > 0 && <span className="inline-flex items-center gap-1"><MessageSquare size={12} />{t.commentCount}</span>}
                </span>
              </td>
              <td className="px-3 py-3" onClick={(e) => e.stopPropagation()}>
                {onStatusChange && t.canUpdate ? (
                  <Select size="sm" className="w-[138px]" value={t.status} onChange={(e) => onStatusChange(t, e.target.value)} aria-label={`Status of ${t.title}`}>
                    {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </Select>
                ) : (
                  <StatusBadge status={t.status} />
                )}
              </td>
              <td className="px-3 py-3"><PriorityMark priority={t.priority} /></td>
              <td className="max-w-[170px] px-3 py-3"><Person user={t.assignee} /></td>
              <td className={cn('whitespace-nowrap px-3 py-3', t.isOverdue ? 'font-semibold text-danger' : 'text-muted')}>
                {formatDate(t.dueDate)}{t.isOverdue && ' · overdue'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
