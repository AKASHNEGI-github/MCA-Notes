import { Avatar, EmptyState } from '../ui';
import { describeActivity } from '../../lib/constants';
import { History } from 'lucide-react';
import { timeAgo, formatDateTime } from '../../lib/format';

/** Renders audit-log rows as readable sentences ("Maya changed the status (To do → Done)"). */
export default function ActivityList({ logs, showProject = false, emptyText = 'Nothing has happened yet.' }) {
  if (!logs?.length) return <EmptyState icon={History} title="No activity" description={emptyText} />;
  return (
    <ol className="divide-y divide-line">
      {logs.map((log) => (
        <li key={log.id} className="flex gap-3 px-4 py-3">
          <Avatar name={log.actor?.name ?? 'System'} size={28} />
          <div className="min-w-0 flex-1">
            <p className="text-sm text-ink">
              <span className="font-semibold">{log.actor?.name ?? 'Someone'}</span>{' '}
              <span className="break-words text-muted">{describeActivity(log)}</span>
            </p>
            <p className="mt-0.5 text-xs text-subtle" title={formatDateTime(log.createdAt)}>
              {timeAgo(log.createdAt)}
              {showProject && log.projectName ? ` · ${log.projectName}` : ''}
            </p>
          </div>
        </li>
      ))}
    </ol>
  );
}
