import { useEffect, useState } from 'react';
import { Pencil, Send, Trash2 } from 'lucide-react';
import { del, get, getErrorMessage, getFieldErrors, patch, post, put } from '../../lib/api';
import { useFetch } from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { PRIORITIES, STATUSES } from '../../lib/constants';
import { formatDateTime, timeAgo } from '../../lib/format';
import { Avatar, Button, ConfirmDialog, Drawer, ErrorState, Field, FormError, IconButton, Input, PageLoader, Select, Spinner, Tabs, Textarea } from '../ui';
import ActivityList from './ActivityList';

/* ------------------------------ comments ------------------------------ */
function Comments({ projectId, taskId, canComment, onCountChange }) {
  const toast = useToast();
  const base = `/projects/${projectId}/tasks/${taskId}/comments`;
  const { data, loading, error, reload } = useFetch(() => get(base), [taskId]);
  const [draft, setDraft] = useState('');
  const [posting, setPosting] = useState(false);
  const [editing, setEditing] = useState(null); // { id, body }
  const [deleting, setDeleting] = useState(null);

  const refresh = async () => { await reload({ silent: true }); onCountChange?.(); };

  const add = async (e) => {
    e.preventDefault();
    if (!draft.trim()) return;
    setPosting(true);
    try {
      await post(base, { body: draft });
      setDraft('');
      await refresh();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setPosting(false);
    }
  };

  const saveEdit = async () => {
    try {
      await put(`${base}/${editing.id}`, { body: editing.body });
      setEditing(null);
      await refresh();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const confirmDelete = async () => {
    try {
      await del(`${base}/${deleting.id}`);
      setDeleting(null);
      await refresh();
    } catch (err) {
      toast.error(getErrorMessage(err));
      setDeleting(null);
    }
  };

  if (loading && !data) return <div className="flex justify-center py-8"><Spinner /></div>;
  if (error) return <ErrorState message={error} onRetry={reload} />;

  return (
    <div className="px-5 py-4">
      {data.length === 0 && <p className="py-4 text-center text-sm text-muted">No comments yet.</p>}
      <ul className="space-y-4">
        {data.map((c) => (
          <li key={c.id} className="flex gap-3">
            <Avatar name={c.author.name} size={30} />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold">{c.author.name}</span>
                <span className="text-xs text-subtle" title={formatDateTime(c.createdAt)}>{timeAgo(c.createdAt)}{c.isEdited && ' · edited'}</span>
                <span className="ml-auto flex">
                  {c.canEdit && <IconButton icon={Pencil} label="Edit comment" onClick={() => setEditing({ id: c.id, body: c.body })} />}
                  {c.canDelete && <IconButton icon={Trash2} label="Delete comment" onClick={() => setDeleting(c)} />}
                </span>
              </div>
              {editing?.id === c.id ? (
                <div className="mt-1.5 space-y-2">
                  <Textarea rows={3} value={editing.body} onChange={(e) => setEditing({ ...editing, body: e.target.value })} />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={saveEdit}>Save</Button>
                    <Button size="sm" variant="secondary" onClick={() => setEditing(null)}>Cancel</Button>
                  </div>
                </div>
              ) : (
                <p className="mt-0.5 whitespace-pre-wrap break-words text-sm text-ink">{c.body}</p>
              )}
            </div>
          </li>
        ))}
      </ul>

      {canComment ? (
        <form onSubmit={add} className="mt-5 flex items-end gap-2">
          <Textarea rows={2} value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Write a comment" aria-label="Write a comment" />
          <Button type="submit" icon={Send} loading={posting} disabled={!draft.trim()}>Post</Button>
        </form>
      ) : (
        <p className="mt-5 text-xs text-subtle">You have read-only access, so you cannot comment.</p>
      )}

      {deleting && (
        <ConfirmDialog title="Delete this comment?" message="It will disappear from the task. This cannot be undone from the app." confirmLabel="Delete comment" danger onConfirm={confirmDelete} onClose={() => setDeleting(null)} />
      )}
    </div>
  );
}

/* ------------------------------ activity ------------------------------ */
function TaskActivity({ projectId, taskId }) {
  const { data, loading, error, reload } = useFetch(() => get(`/projects/${projectId}/tasks/${taskId}/activity`, { limit: 30 }), [taskId]);
  if (loading && !data) return <div className="flex justify-center py-8"><Spinner /></div>;
  if (error) return <ErrorState message={error} onRetry={reload} />;
  return <ActivityList logs={data} />;
}

/* ------------------------------ drawer ------------------------------ */
const EMPTY = { title: '', description: '', status: 'TODO', priority: 'MEDIUM', assigneeId: '', dueDate: '' };

/**
 * Create (taskId = null) or view/edit a task. Fields are read-only when the API says the
 * caller cannot update this task (`task.canUpdate`) or the project is archived.
 */
export default function TaskDrawer({ project, taskId, members, onClose, onChanged }) {
  const toast = useToast();
  const isNew = taskId == null;
  const { data: task, loading, error, reload } = useFetch(() => get(`/projects/${project.id}/tasks/${taskId}`), [taskId], { enabled: !isNew });
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [tab, setTab] = useState('comments');

  const archived = project.status === 'ARCHIVED';
  const canEdit = isNew ? true : Boolean(task?.canUpdate) && !archived;
  const canComment = project.permissions.includes('comment:create') && !archived;

  useEffect(() => {
    if (task) {
      setForm({
        title: task.title,
        description: task.description ?? '',
        status: task.status,
        priority: task.priority,
        assigneeId: task.assignee?.id ?? '',
        dueDate: task.dueDate ?? '',
      });
    }
  }, [task]);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const save = async () => {
    setErrors({});
    setFormError('');
    setSaving(true);
    const payload = {
      title: form.title,
      description: form.description.trim() || null,
      status: form.status,
      priority: form.priority,
      assigneeId: form.assigneeId === '' ? null : Number(form.assigneeId),
      dueDate: form.dueDate || null,
    };
    try {
      if (isNew) {
        await post(`/projects/${project.id}/tasks`, payload);
        toast.success('Task created');
        onChanged();
        onClose();
      } else {
        await put(`/projects/${project.id}/tasks/${taskId}`, payload);
        toast.success('Task saved');
        onChanged();
        await reload({ silent: true });
      }
    } catch (err) {
      setErrors(getFieldErrors(err));
      setFormError(err.response?.status === 422 ? '' : getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    setDeleting(true);
    try {
      await del(`/projects/${project.id}/tasks/${taskId}`);
      toast.success('Task deleted');
      onChanged();
      onClose();
    } catch (err) {
      toast.error(getErrorMessage(err));
      setConfirmDelete(false);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <Drawer
      title={isNew ? 'New task' : 'Task details'}
      onClose={onClose}
      footer={
        <>
          <div>{!isNew && task?.canDelete && !archived && <Button variant="danger-soft" icon={Trash2} onClick={() => setConfirmDelete(true)}>Delete</Button>}</div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>{canEdit ? 'Cancel' : 'Close'}</Button>
            {canEdit && <Button onClick={save} loading={saving}>{isNew ? 'Create task' : 'Save changes'}</Button>}
          </div>
        </>
      }
    >
      {!isNew && loading && !task ? (
        <PageLoader />
      ) : !isNew && error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : (
        <>
          <div className="space-y-4 px-5 py-5">
            <FormError message={formError} />
            {!isNew && !canEdit && (
              <p className="rounded-control bg-sunken px-3 py-2 text-[13px] text-muted">
                {archived ? 'This project is archived, so tasks are read-only.' : 'You can view this task. Only its assignee, its creator, or a project owner can change it.'}
              </p>
            )}
            <Field label="Title" error={errors.title}>
              <Input value={form.title} onChange={set('title')} error={errors.title} disabled={!canEdit} placeholder="What needs to be done?" autoFocus={isNew} />
            </Field>
            <Field label="Description" error={errors.description}>
              <Textarea rows={4} value={form.description} onChange={set('description')} error={errors.description} disabled={!canEdit} placeholder="Add details, links or acceptance criteria" />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Status">
                <Select value={form.status} onChange={set('status')} disabled={!canEdit}>{STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}</Select>
              </Field>
              <Field label="Priority">
                <Select value={form.priority} onChange={set('priority')} disabled={!canEdit}>{PRIORITIES.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}</Select>
              </Field>
              <Field label="Assignee" error={errors.assigneeId}>
                <Select value={form.assigneeId} onChange={set('assigneeId')} disabled={!canEdit}>
                  <option value="">Unassigned</option>
                  {members.map((m) => <option key={m.userId} value={m.userId}>{m.name}</option>)}
                </Select>
              </Field>
              <Field label="Due date" error={errors.dueDate}>
                <Input type="date" value={form.dueDate} onChange={set('dueDate')} error={errors.dueDate} disabled={!canEdit} />
              </Field>
            </div>
            {!isNew && task && (
              <p className="text-xs text-subtle">
                Created by {task.createdBy?.name ?? 'a removed user'} · {formatDateTime(task.createdAt)}
              </p>
            )}
          </div>

          {!isNew && (
            <div className="border-t border-line">
              <div className="px-3">
                <Tabs value={tab} onChange={setTab} tabs={[{ value: 'comments', label: 'Comments', count: task?.commentCount }, { value: 'activity', label: 'Activity' }]} />
              </div>
              {tab === 'comments'
                ? <Comments projectId={project.id} taskId={taskId} canComment={canComment} onCountChange={() => { reload({ silent: true }); onChanged(); }} />
                : <TaskActivity projectId={project.id} taskId={taskId} />}
            </div>
          )}
        </>
      )}

      {confirmDelete && (
        <ConfirmDialog title="Delete this task?" message="The task and its comments will be removed from the project." confirmLabel="Delete task" danger loading={deleting} onConfirm={remove} onClose={() => setConfirmDelete(false)} />
      )}
    </Drawer>
  );
}
