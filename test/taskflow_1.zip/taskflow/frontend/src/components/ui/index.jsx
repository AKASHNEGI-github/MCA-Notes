import { useEffect, useRef } from 'react';
import { AlertTriangle, ChevronDown, ChevronLeft, ChevronRight, Inbox, Loader2, X } from 'lucide-react';
import { cn, initials } from '../../lib/format';
import { priorityMeta, statusMeta } from '../../lib/constants';

/* ------------------------------ buttons ------------------------------ */
const BUTTON_VARIANTS = {
  primary: 'bg-primary text-on-primary hover:bg-primary-hover border-transparent',
  secondary: 'bg-surface text-ink border-line-strong hover:bg-sunken',
  ghost: 'bg-transparent text-muted border-transparent hover:bg-sunken hover:text-ink',
  danger: 'bg-danger text-white border-transparent hover:opacity-90',
  'danger-soft': 'bg-danger-soft text-danger border-transparent hover:opacity-80',
};

export function Button({ variant = 'primary', size = 'md', loading = false, icon: Icon, children, className, disabled, type = 'button', ...props }) {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-control border font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-55',
        size === 'sm' ? 'h-8 px-3 text-[13px]' : 'h-10 px-4 text-sm',
        BUTTON_VARIANTS[variant],
        className
      )}
      {...props}
    >
      {loading ? <Loader2 size={16} className="animate-spin" /> : Icon && <Icon size={16} />}
      {children}
    </button>
  );
}

export function IconButton({ icon: Icon, label, className, ...props }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      className={cn('inline-flex h-8 w-8 items-center justify-center rounded-control text-muted transition-colors hover:bg-sunken hover:text-ink disabled:opacity-50', className)}
      {...props}
    >
      <Icon size={16} />
    </button>
  );
}

/* ------------------------------ form controls ------------------------------ */
const controlBase =
  'w-full rounded-control border bg-surface px-3 text-sm text-ink placeholder:text-subtle transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:bg-sunken disabled:text-muted';

export function Field({ label, error, hint, children, className }) {
  return (
    <label className={cn('block', className)}>
      {label && <span className="mb-1.5 block text-[13px] font-semibold text-ink">{label}</span>}
      {children}
      {error ? <span className="mt-1 block text-xs text-danger">{error}</span> : hint ? <span className="mt-1 block text-xs text-muted">{hint}</span> : null}
    </label>
  );
}

export function Input({ error, className, ...props }) {
  return <input className={cn(controlBase, 'h-10', error ? 'border-danger' : 'border-line-strong', className)} {...props} />;
}

export function Textarea({ error, className, rows = 4, ...props }) {
  return <textarea rows={rows} className={cn(controlBase, 'resize-y py-2', error ? 'border-danger' : 'border-line-strong', className)} {...props} />;
}

export function Select({ error, className, children, size = 'md', ...props }) {
  return (
    <div className={cn('relative', className)}>
      <select
        className={cn(controlBase, 'appearance-none pr-9', size === 'sm' ? 'h-8 text-[13px]' : 'h-10', error ? 'border-danger' : 'border-line-strong')}
        {...props}
      >
        {children}
      </select>
      <ChevronDown size={16} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-subtle" />
    </div>
  );
}

/* ------------------------------ badges ------------------------------ */
const TONES = {
  neutral: 'bg-neutral-soft text-muted',
  info: 'bg-info-soft text-info',
  warning: 'bg-warning-soft text-warning',
  success: 'bg-success-soft text-success',
  danger: 'bg-danger-soft text-danger',
  primary: 'bg-primary-soft text-primary',
};

export function Badge({ tone = 'neutral', children, className }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold', TONES[tone], className)}>
      {children}
    </span>
  );
}

export function StatusBadge({ status }) {
  const m = statusMeta(status);
  return (
    <Badge tone={m.tone}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {m.label}
    </Badge>
  );
}

/** Priority is shown as signal bars (1-4) so it can be scanned down a column. */
export function PriorityMark({ priority, showLabel = true }) {
  const m = priorityMeta(priority);
  return (
    <span className={cn('inline-flex items-center gap-2 text-[13px] font-medium', TONES[m.tone].split(' ')[1])}>
      <span className="flex h-3.5 items-end gap-[2px]" aria-hidden>
        {[1, 2, 3, 4].map((i) => (
          <span key={i} className={cn('w-[3px] rounded-sm bg-current', i > m.bars && 'opacity-25')} style={{ height: `${25 + i * 18}%` }} />
        ))}
      </span>
      {showLabel && m.label}
    </span>
  );
}

const ROLE_TONES = { ADMIN: 'danger', MANAGER: 'primary', OWNER: 'primary', EDITOR: 'info', VIEWER: 'neutral', MEMBER: 'neutral' };
export const RoleBadge = ({ role }) => (role ? <Badge tone={ROLE_TONES[role] ?? 'neutral'}>{role.charAt(0) + role.slice(1).toLowerCase()}</Badge> : null);

export function Avatar({ name, size = 28, className }) {
  return (
    <span
      className={cn('inline-flex shrink-0 items-center justify-center rounded-full bg-primary-soft font-bold text-primary', className)}
      style={{ width: size, height: size, fontSize: Math.round(size * 0.38) }}
      aria-hidden
    >
      {initials(name)}
    </span>
  );
}

export function Person({ user, empty = 'Unassigned' }) {
  if (!user) return <span className="text-subtle">{empty}</span>;
  return (
    <span className="inline-flex items-center gap-2">
      <Avatar name={user.name} size={22} />
      <span className="truncate">{user.name}</span>
    </span>
  );
}

/* ------------------------------ layout bits ------------------------------ */
export const Card = ({ className, children }) => (
  <div className={cn('rounded-panel border border-line bg-surface shadow-panel', className)}>{children}</div>
);

export function PageHeader({ title, description, actions }) {
  return (
    <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
      <div className="min-w-0">
        <h1 className="text-[22px] font-bold leading-tight tracking-tight text-ink">{title}</h1>
        {description && <p className="mt-1 max-w-2xl text-sm text-muted">{description}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="flex gap-1 overflow-x-auto border-b border-line" role="tablist">
      {tabs.map((t) => (
        <button
          key={t.value}
          role="tab"
          aria-selected={value === t.value}
          onClick={() => onChange(t.value)}
          className={cn(
            '-mb-px flex items-center gap-2 whitespace-nowrap border-b-2 px-3.5 py-2.5 text-sm font-semibold transition-colors',
            value === t.value ? 'border-primary text-primary' : 'border-transparent text-muted hover:text-ink'
          )}
        >
          {t.label}
          {t.count !== undefined && <span className="rounded-full bg-neutral-soft px-1.5 text-xs text-muted">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

export function ProgressBar({ value, className }) {
  return (
    <div className={cn('h-1.5 w-full overflow-hidden rounded-full bg-sunken', className)} role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${value}%` }} />
    </div>
  );
}

/* ------------------------------ states ------------------------------ */
export const Spinner = ({ className }) => <Loader2 className={cn('animate-spin text-primary', className)} size={20} />;

export const PageLoader = () => (
  <div className="flex h-48 items-center justify-center"><Spinner /></div>
);

export function EmptyState({ icon: Icon = Inbox, title, description, action }) {
  return (
    <div className="flex flex-col items-center px-6 py-14 text-center">
      <span className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-sunken text-subtle"><Icon size={20} /></span>
      <h3 className="text-[15px] font-semibold text-ink">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-muted">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }) {
  return (
    <div className="flex flex-col items-center px-6 py-12 text-center">
      <span className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-danger-soft text-danger"><AlertTriangle size={20} /></span>
      <h3 className="text-[15px] font-semibold">Could not load this</h3>
      <p className="mt-1 max-w-sm text-sm text-muted">{message}</p>
      {onRetry && <Button variant="secondary" size="sm" className="mt-4" onClick={() => onRetry()}>Try again</Button>}
    </div>
  );
}

export const FormError = ({ message }) =>
  message ? <div role="alert" className="rounded-control bg-danger-soft px-3 py-2 text-sm text-danger">{message}</div> : null;

/* ------------------------------ overlays ------------------------------ */
function useOverlay(onClose) {
  const ref = useRef(null);
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    ref.current?.focus();
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = previous;
    };
  }, [onClose]);
  return ref;
}

export function Modal({ title, description, onClose, children, footer, width = 'max-w-lg' }) {
  const ref = useOverlay(onClose);
  return (
    <div className="anim-fade-in fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title} className={cn('anim-pop-in flex max-h-[92vh] w-full flex-col rounded-t-panel bg-surface shadow-float focus:outline-none sm:rounded-panel', width)}>
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
          <div>
            <h2 className="text-base font-bold">{title}</h2>
            {description && <p className="mt-0.5 text-sm text-muted">{description}</p>}
          </div>
          <IconButton icon={X} label="Close" onClick={onClose} />
        </div>
        <div className="overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line px-5 py-3">{footer}</div>}
      </div>
    </div>
  );
}

export function Drawer({ title, onClose, children, footer, headerExtra }) {
  const ref = useOverlay(onClose);
  return (
    <div className="anim-fade-in fixed inset-0 z-50 flex justify-end bg-ink/40" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <aside ref={ref} tabIndex={-1} role="dialog" aria-modal="true" aria-label={title} className="anim-slide-in flex h-full w-full max-w-[560px] flex-col bg-surface shadow-float focus:outline-none">
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-3.5">
          <h2 className="truncate text-base font-bold">{title}</h2>
          <div className="flex items-center gap-1">
            {headerExtra}
            <IconButton icon={X} label="Close" onClick={onClose} />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">{children}</div>
        {footer && <div className="flex justify-between gap-2 border-t border-line px-5 py-3">{footer}</div>}
      </aside>
    </div>
  );
}

export function ConfirmDialog({ title, message, confirmLabel = 'Confirm', danger = false, loading, onConfirm, onClose }) {
  return (
    <Modal
      title={title}
      onClose={onClose}
      width="max-w-md"
      footer={
        <>
          <Button variant="secondary" onClick={onClose} disabled={loading}>Cancel</Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm} loading={loading}>{confirmLabel}</Button>
        </>
      }
    >
      <p className="text-sm text-muted">{message}</p>
    </Modal>
  );
}

/* ------------------------------ pagination ------------------------------ */
export function Pagination({ meta, onPage }) {
  if (!meta || meta.totalPages <= 1) return meta ? <p className="px-4 py-3 text-xs text-muted">{meta.total} {meta.total === 1 ? 'result' : 'results'}</p> : null;
  const from = (meta.page - 1) * meta.limit + 1;
  const to = Math.min(meta.page * meta.limit, meta.total);
  return (
    <div className="flex items-center justify-between gap-3 border-t border-line px-4 py-3">
      <p className="text-xs text-muted">{from}–{to} of {meta.total}</p>
      <div className="flex items-center gap-1">
        <Button variant="secondary" size="sm" disabled={!meta.hasPrev} onClick={() => onPage(meta.page - 1)} icon={ChevronLeft}>Prev</Button>
        <span className="px-2 text-xs text-muted">Page {meta.page} / {meta.totalPages}</span>
        <Button variant="secondary" size="sm" disabled={!meta.hasNext} onClick={() => onPage(meta.page + 1)}>Next <ChevronRight size={16} /></Button>
      </div>
    </div>
  );
}
