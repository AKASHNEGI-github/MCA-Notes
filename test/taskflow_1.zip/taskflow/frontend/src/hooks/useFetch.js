import { useCallback, useEffect, useRef, useState } from 'react';
import { getErrorMessage } from '../lib/api';

/**
 * useFetch(fn, deps) - runs `fn()` (which returns the API envelope) whenever deps change.
 * Returns { data, meta, loading, error, reload }. Stale responses are ignored.
 */
export function useFetch(fn, deps = [], { enabled = true } = {}) {
  const [state, setState] = useState({ data: null, meta: null, loading: enabled, error: null });
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const runId = useRef(0);

  const run = useCallback(async ({ silent = false } = {}) => {
    const id = ++runId.current;
    if (!silent) setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const res = await fnRef.current();
      if (id === runId.current) setState({ data: res.data, meta: res.meta ?? null, loading: false, error: null });
    } catch (err) {
      if (id === runId.current) setState((s) => ({ ...s, loading: false, error: getErrorMessage(err) }));
    }
  }, []);

  useEffect(() => {
    if (enabled) run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, ...deps]);

  return { ...state, reload: run };
}
