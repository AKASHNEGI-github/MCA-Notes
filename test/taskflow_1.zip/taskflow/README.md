# TaskFlow

A multi-role task management app built to practise real backend concepts:
authentication, RBAC (global + project level), a request context store, custom exception
classes, a standard API response, soft delete everywhere, and an audit trail.

**Stack:** React 19 + Vite + Tailwind v4 (frontend) · Express 5 (backend) · MySQL 8 with raw SQL (no ORM, no query builder).

---

## 1. Run it

You need Node 20+ and MySQL 8+.

```bash
# 1) Backend
cd backend
cp .env.example .env          # then edit DB_USER / DB_PASSWORD (or set DATABASE_URL)
npm install
npm run db:init               # creates the database, tables, roles, permissions and the first admin
npm run dev                   # http://localhost:4000/api/v1

# 2) Frontend (new terminal)
cd frontend
cp .env.example .env
npm install
npm run dev                   # http://localhost:5173  (proxies /api to the backend)
```

First admin (from `ADMIN_*` in `backend/.env`): `admin@taskflow.local` / `Admin@12345`. Change it after signing in.

**Database connection.** If `DATABASE_URL` is set (`mysql://user:pass@host:3306/db`) it wins; otherwise the app uses
`DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`. `npm run db:init` creates the database itself in local mode
and is safe to run repeatedly. You can also run `database/mysql/schema.sql` and `seed.sql` by hand.

---

## 2. What is built (phases 1-3)

| Phase | Backend | Frontend |
|---|---|---|
| 1 - MVP | register / login / logout / me, users, projects, tasks, global roles | login, register, forgot password (UI only), dashboard, projects, tasks |
| 2 - Core | project membership + project roles, comments, filters / sort / search / pagination | members tab, task drawer with comments, task filters, my tasks |
| 3 - Advanced | audit log through the request context store, dashboards, refresh-token rotation with reuse detection, change password | activity feeds, overview tab, admin users, admin audit log, profile |

Forgot password exists only in the UI. Submitting it does not call the API (the reset flow is intentionally not built yet).

---

## 3. Backend structure

```
backend/src
  config/        env.js (all env vars), db.js (mysql2 pool, query(), queryOne(), transaction())
  constants/     roles, permissions, enums, audit action names
  middleware/    requestContext, authenticate, authorize, projectAccess, validate, errorHandler, notFound
  utils/         errors, apiResponse, requestContext (AsyncLocalStorage), tokens, password, pagination, diff, mappers, schemas
  modules/
    auth/        auth.router.js  auth.schema.js  auth.service.js
    users/       (profile + people directory)
    admin/       (user management, roles, system audit log)
    projects/  members/  tasks/  comments/  audit/  dashboard/
  routes.js      mounts every module
  app.js / server.js
database/mysql/  schema.sql, seed.sql
```

Each module = **router** (HTTP only) + **schema** (zod validation) + **service** (business rules and raw SQL).
There is no controller or repository layer: services talk to MySQL directly through `query()` / `transaction()`.

### Concepts and where to find them

| Concept | Where |
|---|---|
| Request context store | `utils/requestContext.js` (AsyncLocalStorage), opened in `middleware/requestContext.js`, filled by `authenticate` and `projectAccess`. Services read it with `getCurrentUserId()` to set `created_by` / `updated_by` / `deleted_by` and to write audit logs, so the user is never passed through function arguments. |
| Authentication | `modules/auth/*`, `middleware/authenticate.js`. Access JWT (15 min) + opaque refresh token (7 days, stored as a sha256 hash). Both tokens are returned in the response body. |
| Refresh rotation | `auth.service.js -> refresh()`. Each refresh revokes the old token and issues a new one in the same family. Reusing a revoked token revokes the whole family. |
| Credentials | Separate `passwords` table, one row per user. Only the auth flow reads it. |
| Authorization (RBAC) | Permission based: `roles`, `permissions`, `role_permissions`. Global roles (ADMIN, MANAGER, MEMBER) and project roles (OWNER, EDITOR, VIEWER) live in the same tables, split by `scope`. `authorize('user:read')` checks the global role; `projectAccess('task:create')` resolves the caller's role **in that project**. Task-level rule: `task:update-own` only allows tasks the user created or is assigned to. |
| Custom exceptions | `utils/errors.js`: `AppError(statusCode, message, code, errors)` and subclasses `BadRequestError` 400, `UnauthorizedError` 401, `ForbiddenError` 403, `NotFoundError` 404, `ConflictError` 409, `ValidationError` 422. `middleware/errorHandler.js` is the single place that turns errors (and MySQL duplicate-key errors) into responses. |
| Standard response | `utils/apiResponse.js` |
| Soft delete | Every table has `deleted_at`; every query filters `deleted_at IS NULL`. There is no `DELETE FROM` anywhere. See section 5. |
| Transactions | `transaction(async (conn) => ...)`, e.g. project + owner membership + audit row are created atomically. |

### Standard API response

```jsonc
// success
{ "success": true, "message": "Tasks fetched", "data": [ ... ], "meta": { "page": 1, "limit": 10, "total": 42, "totalPages": 5, "hasNext": true, "hasPrev": false } }
// error
{ "success": false, "message": "Validation failed", "code": "VALIDATION_ERROR", "errors": [ { "field": "email", "message": "Enter a valid email address", "location": "body" } ] }
```

`meta` is `null` when there is nothing to paginate. Machine-readable `code` values include `TOKEN_EXPIRED`, `FORBIDDEN`,
`NOT_PROJECT_MEMBER`, `PROJECT_NOT_FOUND`, `EMAIL_TAKEN`, `LAST_OWNER`, `LAST_ADMIN`, `PROJECT_ARCHIVED`, `REFRESH_TOKEN_REUSED` and more.

---

## 4. Roles and permissions

**Global roles** (`users.role_id`)

| | Admin | Manager | Member |
|---|:-:|:-:|:-:|
| Manage users, assign roles, system audit log | yes | | |
| Create projects (becomes OWNER) | yes | yes | |
| Open every project with full rights | yes | | |

New registrations are `MEMBER`. Only an admin can promote someone.

**Project roles** (`project_members.role_id`) - a user can be OWNER in one project and VIEWER in another.

| Permission | Owner | Editor | Viewer |
|---|:-:|:-:|:-:|
| View project, tasks, comments | yes | yes | yes |
| Create tasks, write comments | yes | yes | |
| Update any task | yes | | |
| Update tasks created by / assigned to them | yes | yes | |
| Delete tasks, delete anyone's comment | yes | | |
| Edit / archive / delete project, manage members, project activity feed | yes | | |

Business rules worth reading in the code: a project always keeps one owner (`LAST_OWNER`), the platform always keeps one
active admin (`LAST_ADMIN`), a user who is the sole owner of a project cannot be deleted, archived projects are read-only,
admins cannot change or delete themselves, and a deactivated user's token stops working immediately because permissions are
loaded from the database on every request.

---

## 5. Soft delete rules

- Deleting a **project** soft-deletes its members, tasks and comments in one transaction.
- Deleting a **task** soft-deletes its comments.
- Deleting a **user** soft-deletes the user, their password row and their memberships, revokes their refresh tokens and unassigns their tasks. Their **email stays reserved** and cannot be registered again.
- Removing a **project member** soft-deletes the membership. Adding the same person again **restores** that row (this is why `UNIQUE (project_id, user_id)` can stay in place).
- Two intentional exceptions: `refresh_tokens` use `revoked_at`, and `audit_logs` is an append-only ledger.

---

## 6. API reference (`/api/v1`)

Everything except the public auth routes needs `Authorization: Bearer <accessToken>`.

| Area | Endpoints |
|---|---|
| Auth | `POST /auth/register` `POST /auth/login` `POST /auth/refresh` `POST /auth/logout` · `GET /auth/me` `PUT /auth/change-password` `POST /auth/logout-all` |
| Users | `GET /users/directory?search=` `PUT /users/me` |
| Admin | `GET/POST /admin/users` `GET/PUT/DELETE /admin/users/:userId` `PUT /admin/users/:userId/role` `GET /admin/roles?scope=` `GET /admin/audit-logs` |
| Projects | `GET/POST /projects` `GET /projects/roles` `GET/PUT/DELETE /projects/:projectId` |
| Members | `GET/POST /projects/:projectId/members` `PUT/DELETE /projects/:projectId/members/:userId` |
| Tasks | `GET/POST /projects/:projectId/tasks` `GET/PUT/DELETE /projects/:projectId/tasks/:taskId` `PATCH .../:taskId/status` `GET .../:taskId/activity` · `GET /tasks/my` |
| Comments | `GET/POST /projects/:projectId/tasks/:taskId/comments` `PUT/DELETE .../comments/:commentId` |
| Activity | `GET /projects/:projectId/activity` |
| Dashboard | `GET /dashboard` `GET /dashboard/projects/:projectId` |

Task list query: `status, priority, assigneeId, unassigned, search, overdue, dueFrom, dueTo, sortBy (createdAt|updatedAt|title|status|priority|dueDate), sortOrder, page, limit (max 100)`.

---

## 7. Frontend structure and theme

```
frontend/src
  lib/          api.js (axios + token refresh), constants.js, format.js
  context/      AuthContext, ToastContext
  hooks/        useFetch, useDebounce
  components/   ui/ (buttons, inputs, modal, drawer, tabs...), layout/, tasks/, projects/
  pages/        auth/, admin/, project/ (tabs), Dashboard, Projects, MyTasks, Profile
```

- `lib/api.js` attaches the access token and, on `TOKEN_EXPIRED`, refreshes **once** (single-flight) and retries. This matters because the server rotates refresh tokens and treats a replayed one as theft.
- **Theme:** light only. All colours are semantic CSS variables in `src/index.css` (`--canvas`, `--surface`, `--ink`, `--primary`...) exposed to Tailwind through `@theme inline`. Components never use raw colours, so a dark theme later means adding one block that redefines the variables.
- The UI hides what a role cannot do (buttons, tabs, pages), but the API enforces every rule on its own.
