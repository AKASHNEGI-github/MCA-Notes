import dotenv from 'dotenv';

dotenv.config();

const toInt = (value, fallback) => {
  const n = parseInt(value, 10);
  return Number.isNaN(n) ? fallback : n;
};

export const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  isProduction: process.env.NODE_ENV === 'production',
  port: toInt(process.env.PORT, 4000),
  corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:5173',

  db: {
    url: process.env.DATABASE_URL || '',
    host: process.env.DB_HOST || 'localhost',
    port: toInt(process.env.DB_PORT, 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    name: process.env.DB_NAME || 'taskflow',
    poolSize: toInt(process.env.DB_POOL_SIZE, 10),
  },

  auth: {
    accessSecret: process.env.JWT_ACCESS_SECRET || 'dev-only-access-secret-change-me-please',
    accessTtl: process.env.ACCESS_TOKEN_TTL || '15m',
    refreshTtlDays: toInt(process.env.REFRESH_TOKEN_TTL_DAYS, 7),
    bcryptRounds: toInt(process.env.BCRYPT_ROUNDS, 10),
  },

  admin: {
    name: process.env.ADMIN_NAME || 'Platform Admin',
    email: (process.env.ADMIN_EMAIL || 'admin@taskflow.local').toLowerCase(),
    password: process.env.ADMIN_PASSWORD || 'Admin@12345',
  },
};

if (env.isProduction && env.auth.accessSecret.startsWith('dev-only')) {
  throw new Error('JWT_ACCESS_SECRET must be set in production');
}
