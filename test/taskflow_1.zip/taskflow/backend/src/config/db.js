import mysql from 'mysql2/promise';
import { env } from './env.js';

const baseOptions = {
  waitForConnections: true,
  connectionLimit: env.db.poolSize,
  timezone: 'Z', // JS <-> MySQL conversions are done in UTC
  dateStrings: ['DATE'], // keep DATE columns as 'YYYY-MM-DD' (no timezone shifting)
  charset: 'utf8mb4',
};

// DATABASE_URL wins when present, otherwise the discrete DB_* values are used.
export const pool = env.db.url
  ? mysql.createPool({ uri: env.db.url, ...baseOptions })
  : mysql.createPool({
      host: env.db.host,
      port: env.db.port,
      user: env.db.user,
      password: env.db.password,
      database: env.db.name,
      ...baseOptions,
    });

// Every connection works in UTC so CURRENT_TIMESTAMP defaults are UTC too.
pool.pool.on('connection', (connection) => {
  connection.query("SET time_zone = '+00:00'");
});

/**
 * Run a raw SQL statement. Pass `conn` to run it inside a transaction.
 * Returns the rows for SELECTs, or the ResultSetHeader (insertId, affectedRows) for writes.
 */
export async function query(sql, params = [], conn = null) {
  const [result] = await (conn || pool).query(sql, params);
  return result;
}

/** First row of a SELECT, or null. */
export async function queryOne(sql, params = [], conn = null) {
  const rows = await query(sql, params, conn);
  return rows[0] ?? null;
}

/** Run `fn(conn)` in a transaction: commit on success, rollback on any thrown error. */
export async function transaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

export async function checkConnection() {
  await pool.query('SELECT 1');
}
