import { Router } from 'express';
import { sendSuccess } from '../../utils/apiResponse.js';
import { validate } from '../../middleware/validate.js';
import * as usersService from './users.service.js';
import { directoryQuery, updateMeBody } from './users.schema.js';

// Every route here requires authentication (applied where the router is mounted).
const router = Router();

router.get('/directory', validate({ query: directoryQuery }), async (req, res) => {
  const data = await usersService.directory(req.query);
  return sendSuccess(res, { message: 'Users fetched', data });
});

router.put('/me', validate({ body: updateMeBody }), async (req, res) => {
  const data = await usersService.updateMe(req.body);
  return sendSuccess(res, { message: 'Profile updated', data });
});

export default router;
