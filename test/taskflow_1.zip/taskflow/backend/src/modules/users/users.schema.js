import { z } from 'zod';
import { emailSchema, nameSchema } from '../../utils/schemas.js';

export const directoryQuery = z.object({
  search: z.string().trim().max(100).optional(),
  limit: z.coerce.number().int().min(1).max(50).default(20),
});

export const updateMeBody = z
  .object({ name: nameSchema.optional(), email: emailSchema.optional() })
  .refine((v) => v.name !== undefined || v.email !== undefined, { message: 'Provide a name or an email to update' });
