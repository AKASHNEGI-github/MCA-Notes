import { query, queryOne, transaction } from '../../config/db.js';
import { AUDIT_ACTION, ENTITY } from '../../constants/index.js';
import { ConflictError } from '../../utils/errors.js';
import { getCurrentUserId } from '../../utils/requestContext.js';
import { diffFields } from '../../utils/diff.js';
import * as auditService from '../audit/audit.service.js';
import { getProfile } from '../auth/auth.service.js';

/** Lightweight list of active users (id / name / email) - powers every "pick a person" control. */
export async function directory({ search, limit }) {
  const params = [];
  let searchSql = '';
  if (search) {
    searchSql = 'AND (u.name LIKE ? OR u.email LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }

  const rows = await query(
    `SELECT u.id, u.name, u.email, r.name AS role_name
       FROM users u
       JOIN roles r ON r.id = u.role_id
      WHERE u.deleted_at IS NULL AND u.is_active = 1 ${searchSql}
      ORDER BY u.name ASC
      LIMIT ?`,
    [...params, limit]
  );
  return rows.map((r) => ({ id: r.id, name: r.name, email: r.email, roleName: r.role_name }));
}

export async function updateMe(input) {
  const userId = getCurrentUserId();
  const before = await queryOne('SELECT name, email FROM users WHERE id = ? AND deleted_at IS NULL', [userId]);

  if (input.email && input.email !== before.email) {
    const taken = await queryOne('SELECT id FROM users WHERE email = ? AND id <> ?', [input.email, userId]);
    if (taken) throw new ConflictError('This email is already in use', 'EMAIL_TAKEN');
  }

  const changes = diffFields(before, input, ['name', 'email']);
  if (Object.keys(changes).length) {
    await transaction(async (conn) => {
      await query(
        'UPDATE users SET name = ?, email = ?, updated_by = ? WHERE id = ?',
        [input.name ?? before.name, input.email ?? before.email, userId, userId],
        conn
      );
      await auditService.log({
        action: AUDIT_ACTION.USER_UPDATED,
        entityType: ENTITY.USER,
        entityId: userId,
        projectId: null,
        changes,
        conn,
      });
    });
  }
  return getProfile();
}
