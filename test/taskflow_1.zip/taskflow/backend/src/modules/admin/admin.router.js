import { Router } from 'express';
import { sendCreated, sendSuccess } from '../../utils/apiResponse.js';
import { PERMISSIONS } from '../../constants/index.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../middleware/authorize.js';
import * as adminService from './admin.service.js';
import * as auditService from '../audit/audit.service.js';
import { listAuditQuery } from '../audit/audit.schema.js';
import {
  assignRoleBody,
  createUserBody,
  listUsersQuery,
  rolesQuery,
  updateUserBody,
  userIdParams,
} from './admin.schema.js';

// Mounted at /admin behind `authenticate`.
const router = Router();

router.get('/users', authorize(PERMISSIONS.USER_READ), validate({ query: listUsersQuery }), async (req, res) => {
  const { items, meta } = await adminService.listUsers(req.query);
  return sendSuccess(res, { message: 'Users fetched', data: items, meta });
});

router.post('/users', authorize(PERMISSIONS.USER_CREATE), validate({ body: createUserBody }), async (req, res) => {
  const data = await adminService.createUser(req.body);
  return sendCreated(res, { message: 'User created', data });
});

router.get('/users/:userId', authorize(PERMISSIONS.USER_READ), validate({ params: userIdParams }), async (req, res) => {
  const data = await adminService.getUser(req.params.userId);
  return sendSuccess(res, { message: 'User fetched', data });
});

router.put(
  '/users/:userId',
  authorize(PERMISSIONS.USER_UPDATE),
  validate({ params: userIdParams, body: updateUserBody }),
  async (req, res) => {
    const data = await adminService.updateUser(req.params.userId, req.body);
    return sendSuccess(res, { message: 'User updated', data });
  }
);

router.put(
  '/users/:userId/role',
  authorize(PERMISSIONS.USER_ASSIGN_ROLE),
  validate({ params: userIdParams, body: assignRoleBody }),
  async (req, res) => {
    const data = await adminService.assignRole(req.params.userId, req.body.roleId);
    return sendSuccess(res, { message: 'Role updated', data });
  }
);

router.delete('/users/:userId', authorize(PERMISSIONS.USER_DELETE), validate({ params: userIdParams }), async (req, res) => {
  await adminService.deleteUser(req.params.userId);
  return sendSuccess(res, { message: 'User deleted' });
});

router.get('/roles', authorize(PERMISSIONS.USER_READ), validate({ query: rolesQuery }), async (req, res) => {
  const data = await adminService.listRoles(req.query);
  return sendSuccess(res, { message: 'Roles fetched', data });
});

router.get('/audit-logs', authorize(PERMISSIONS.AUDIT_READ_ALL), validate({ query: listAuditQuery }), async (req, res) => {
  const { items, meta } = await auditService.list(req.query);
  return sendSuccess(res, { message: 'Audit logs fetched', data: items, meta });
});

export default router;
