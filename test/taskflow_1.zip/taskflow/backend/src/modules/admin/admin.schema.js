import { z } from 'zod';
import { booleanQuery, emailSchema, idSchema, nameSchema, pageQuery, passwordSchema } from '../../utils/schemas.js';

export const userIdParams = z.object({ userId: idSchema });

export const listUsersQuery = z.object({
  ...pageQuery,
  search: z.string().trim().max(100).optional(),
  roleId: idSchema.optional(),
  isActive: booleanQuery.optional(),
});

export const createUserBody = z.object({
  name: nameSchema,
  email: emailSchema,
  password: passwordSchema,
  roleId: idSchema,
});

export const updateUserBody = z
  .object({
    name: nameSchema.optional(),
    email: emailSchema.optional(),
    isActive: z.boolean().optional(),
  })
  .refine((v) => Object.values(v).some((x) => x !== undefined), { message: 'Provide at least one field to update' });

export const assignRoleBody = z.object({ roleId: idSchema });

export const rolesQuery = z.object({ scope: z.enum(['GLOBAL', 'PROJECT']).optional() });
