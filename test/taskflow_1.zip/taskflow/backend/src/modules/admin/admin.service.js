import { query, queryOne, transaction } from '../../config/db.js';
import { AUDIT_ACTION, ENTITY, GLOBAL_ROLES, PROJECT_ROLES } from '../../constants/index.js';
import { BadRequestError, ConflictError, ForbiddenError, NotFoundError } from '../../utils/errors.js';
import { getCurrentUserId } from '../../utils/requestContext.js';
import { hashPassword } from '../../utils/password.js';
import { buildMeta, getPagination } from '../../utils/pagination.js';
import { diffFields } from '../../utils/diff.js';
import { mapUser } from '../../utils/mappers.js';
import * as auditService from '../audit/audit.service.js';

const USER_SELECT = `
  SELECT u.id, u.name, u.email, u.is_active, u.last_login_at, u.created_at, u.updated_at,
         u.role_id, r.name AS role_name
    FROM users u
    JOIN roles r ON r.id = u.role_id`;

async function findUserOrFail(userId, conn = null) {
  const row = await queryOne(`${USER_SELECT} WHERE u.id = ? AND u.deleted_at IS NULL`, [userId], conn);
  if (!row) throw new NotFoundError('User not found', 'USER_NOT_FOUND');
  return row;
}

async function assertGlobalRole(roleId) {
  const role = await queryOne("SELECT id, name FROM roles WHERE id = ? AND scope = 'GLOBAL' AND deleted_at IS NULL", [roleId]);
  if (!role) throw new BadRequestError('Role does not exist or is not a global role', 'INVALID_ROLE');
  return role;
}

/** The platform must always keep at least one active admin. */
async function assertAnotherAdminExists(excludeUserId) {
  const { count } = await queryOne(
    `SELECT COUNT(*) AS count
       FROM users u
       JOIN roles r ON r.id = u.role_id
      WHERE r.scope = 'GLOBAL' AND r.name = ? AND u.deleted_at IS NULL AND u.is_active = 1 AND u.id <> ?`,
    [GLOBAL_ROLES.ADMIN, excludeUserId]
  );
  if (count === 0) throw new ConflictError('At least one active admin is required', 'LAST_ADMIN');
}

/* ------------------------------- users ------------------------------- */

export async function listUsers(filters) {
  const { page, limit, offset } = getPagination(filters);
  const where = ['u.deleted_at IS NULL'];
  const params = [];

  if (filters.search) {
    where.push('(u.name LIKE ? OR u.email LIKE ?)');
    params.push(`%${filters.search}%`, `%${filters.search}%`);
  }
  if (filters.roleId) { where.push('u.role_id = ?'); params.push(filters.roleId); }
  if (filters.isActive !== undefined) { where.push('u.is_active = ?'); params.push(filters.isActive ? 1 : 0); }

  const [{ total }] = await query(`SELECT COUNT(*) AS total FROM users u WHERE ${where.join(' AND ')}`, params);
  const rows = await query(
    `${USER_SELECT} WHERE ${where.join(' AND ')} ORDER BY u.created_at DESC, u.id DESC LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );
  return { items: rows.map(mapUser), meta: buildMeta({ page, limit, total }) };
}

export async function getUser(userId) {
  return mapUser(await findUserOrFail(userId));
}

export async function createUser({ name, email, password, roleId }) {
  await assertGlobalRole(roleId);
  const taken = await queryOne('SELECT id FROM users WHERE email = ?', [email]);
  if (taken) throw new ConflictError('An account with this email already exists', 'EMAIL_TAKEN');

  const passwordHash = await hashPassword(password);
  const actorId = getCurrentUserId();

  const userId = await transaction(async (conn) => {
    const result = await query(
      'INSERT INTO users (name, email, role_id, created_by, updated_by) VALUES (?, ?, ?, ?, ?)',
      [name, email, roleId, actorId, actorId],
      conn
    );
    await query('INSERT INTO passwords (user_id, password_hash) VALUES (?, ?)', [result.insertId, passwordHash], conn);
    await auditService.log({
      action: AUDIT_ACTION.USER_CREATED,
      entityType: ENTITY.USER,
      entityId: result.insertId,
      projectId: null,
      metadata: { email, roleId },
      conn,
    });
    return result.insertId;
  });
  return getUser(userId);
}

export async function updateUser(userId, input) {
  const before = await findUserOrFail(userId);
  const actorId = getCurrentUserId();

  if (input.isActive === false) {
    if (userId === actorId) throw new ForbiddenError('You cannot deactivate your own account', 'SELF_ACTION');
    if (before.role_name === GLOBAL_ROLES.ADMIN) await assertAnotherAdminExists(userId);
  }
  if (input.email && input.email !== before.email) {
    const taken = await queryOne('SELECT id FROM users WHERE email = ? AND id <> ?', [input.email, userId]);
    if (taken) throw new ConflictError('This email is already in use', 'EMAIL_TAKEN');
  }

  const next = {
    name: input.name ?? before.name,
    email: input.email ?? before.email,
    is_active: input.isActive === undefined ? before.is_active : input.isActive ? 1 : 0,
  };
  const changes = diffFields(before, next, ['name', 'email', 'is_active']);

  if (Object.keys(changes).length) {
    await transaction(async (conn) => {
      await query(
        'UPDATE users SET name = ?, email = ?, is_active = ?, updated_by = ? WHERE id = ?',
        [next.name, next.email, next.is_active, actorId, userId],
        conn
      );
      // Deactivated users are signed out everywhere.
      if (next.is_active === 0) {
        await query('UPDATE refresh_tokens SET revoked_at = UTC_TIMESTAMP() WHERE user_id = ? AND revoked_at IS NULL', [userId], conn);
      }
      await auditService.log({
        action: AUDIT_ACTION.USER_UPDATED,
        entityType: ENTITY.USER,
        entityId: userId,
        projectId: null,
        changes,
        conn,
      });
    });
  }
  return getUser(userId);
}

export async function assignRole(userId, roleId) {
  const before = await findUserOrFail(userId);
  const role = await assertGlobalRole(roleId);

  if (userId === getCurrentUserId()) throw new ForbiddenError('You cannot change your own role', 'SELF_ACTION');
  if (before.role_id === roleId) return mapUser(before);
  if (before.role_name === GLOBAL_ROLES.ADMIN) await assertAnotherAdminExists(userId);

  await transaction(async (conn) => {
    await query('UPDATE users SET role_id = ?, updated_by = ? WHERE id = ?', [roleId, getCurrentUserId(), userId], conn);
    await auditService.log({
      action: AUDIT_ACTION.USER_ROLE_CHANGED,
      entityType: ENTITY.USER,
      entityId: userId,
      projectId: null,
      changes: { role: { from: before.role_name, to: role.name } },
      conn,
    });
  });
  return getUser(userId);
}

/** Soft delete - the row, its credentials and its memberships stay in the database, flagged. */
export async function deleteUser(userId) {
  const user = await findUserOrFail(userId);
  const actorId = getCurrentUserId();

  if (userId === actorId) throw new ForbiddenError('You cannot delete your own account', 'SELF_ACTION');
  if (user.role_name === GLOBAL_ROLES.ADMIN) await assertAnotherAdminExists(userId);

  // A project must never be left without an owner.
  const soleOwned = await query(
    `SELECT p.id, p.name
       FROM project_members pm
       JOIN roles r ON r.id = pm.role_id AND r.scope = 'PROJECT' AND r.name = ?
       JOIN projects p ON p.id = pm.project_id AND p.deleted_at IS NULL
      WHERE pm.user_id = ? AND pm.deleted_at IS NULL
        AND NOT EXISTS (
          SELECT 1 FROM project_members o
           WHERE o.project_id = pm.project_id AND o.role_id = pm.role_id
             AND o.user_id <> pm.user_id AND o.deleted_at IS NULL)`,
    [PROJECT_ROLES.OWNER, userId]
  );
  if (soleOwned.length) {
    const names = soleOwned.map((p) => p.name).join(', ');
    throw new ConflictError(`User is the only owner of: ${names}. Transfer ownership first.`, 'SOLE_PROJECT_OWNER');
  }

  await transaction(async (conn) => {
    await query(
      'UPDATE users SET deleted_at = UTC_TIMESTAMP(), deleted_by = ?, is_active = 0 WHERE id = ?',
      [actorId, userId],
      conn
    );
    await query('UPDATE passwords SET deleted_at = UTC_TIMESTAMP() WHERE user_id = ? AND deleted_at IS NULL', [userId], conn);
    await query('UPDATE refresh_tokens SET revoked_at = UTC_TIMESTAMP() WHERE user_id = ? AND revoked_at IS NULL', [userId], conn);
    await query(
      'UPDATE project_members SET deleted_at = UTC_TIMESTAMP(), deleted_by = ? WHERE user_id = ? AND deleted_at IS NULL',
      [actorId, userId],
      conn
    );
    await query(
      'UPDATE tasks SET assignee_id = NULL, updated_by = ? WHERE assignee_id = ? AND deleted_at IS NULL',
      [actorId, userId],
      conn
    );
    await auditService.log({
      action: AUDIT_ACTION.USER_DELETED,
      entityType: ENTITY.USER,
      entityId: userId,
      projectId: null,
      metadata: { email: user.email, name: user.name },
      conn,
    });
  });
}

/* ------------------------------- roles ------------------------------- */

export async function listRoles({ scope } = {}) {
  const roles = await query(
    `SELECT id, name, scope, description FROM roles WHERE deleted_at IS NULL ${scope ? 'AND scope = ?' : ''} ORDER BY scope, id`,
    scope ? [scope] : []
  );
  const perms = await query(
    `SELECT rp.role_id, p.code
       FROM role_permissions rp
       JOIN permissions p ON p.id = rp.permission_id AND p.deleted_at IS NULL
      WHERE rp.deleted_at IS NULL
      ORDER BY p.code`
  );
  return roles.map((r) => ({
    id: r.id,
    name: r.name,
    scope: r.scope,
    description: r.description,
    permissions: perms.filter((p) => p.role_id === r.id).map((p) => p.code),
  }));
}
