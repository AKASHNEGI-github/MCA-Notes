import { query, queryOne, transaction } from '../../config/db.js';
import { AUDIT_ACTION, ENTITY, PROJECT_ROLES } from '../../constants/index.js';
import { BadRequestError, ConflictError, NotFoundError } from '../../utils/errors.js';
import { getCurrentUserId } from '../../utils/requestContext.js';
import * as auditService from '../audit/audit.service.js';

const MEMBER_SELECT = `
  SELECT pm.user_id, pm.role_id, pm.created_at AS joined_at, u.name, u.email, r.name AS role_name,
         (SELECT COUNT(*) FROM tasks t
           WHERE t.project_id = pm.project_id AND t.assignee_id = pm.user_id
             AND t.deleted_at IS NULL AND t.status <> 'DONE') AS open_tasks
    FROM project_members pm
    JOIN users u ON u.id = pm.user_id AND u.deleted_at IS NULL
    JOIN roles r ON r.id = pm.role_id AND r.deleted_at IS NULL`;

const mapMember = (row) => ({
  userId: row.user_id,
  name: row.name,
  email: row.email,
  role: { id: row.role_id, name: row.role_name },
  joinedAt: row.joined_at,
  openTasks: row.open_tasks,
});

const assertProjectActive = (project) => {
  if (project.status === 'ARCHIVED') throw new ConflictError('This project is archived. Restore it to make changes.', 'PROJECT_ARCHIVED');
};

async function assertProjectRole(roleId) {
  const role = await queryOne("SELECT id, name FROM roles WHERE id = ? AND scope = 'PROJECT' AND deleted_at IS NULL", [roleId]);
  if (!role) throw new BadRequestError('Role does not exist or is not a project role', 'INVALID_ROLE');
  return role;
}

async function getMemberOrFail(projectId, userId, conn = null) {
  const row = await queryOne(
    `${MEMBER_SELECT} WHERE pm.project_id = ? AND pm.user_id = ? AND pm.deleted_at IS NULL`,
    [projectId, userId],
    conn
  );
  if (!row) throw new NotFoundError('This user is not a member of the project', 'MEMBER_NOT_FOUND');
  return row;
}

/** A project always keeps at least one owner. */
async function assertNotLastOwner(projectId, member, conn = null) {
  if (member.role_name !== PROJECT_ROLES.OWNER) return;
  const { count } = await queryOne(
    `SELECT COUNT(*) AS count
       FROM project_members pm
       JOIN roles r ON r.id = pm.role_id
      WHERE pm.project_id = ? AND pm.deleted_at IS NULL AND r.name = ? AND r.scope = 'PROJECT' AND pm.user_id <> ?`,
    [projectId, PROJECT_ROLES.OWNER, member.user_id],
    conn
  );
  if (count === 0) throw new ConflictError('A project needs at least one owner', 'LAST_OWNER');
}

export async function list(projectId) {
  const rows = await query(
    `${MEMBER_SELECT}
      WHERE pm.project_id = ? AND pm.deleted_at IS NULL
      ORDER BY FIELD(r.name, 'OWNER', 'EDITOR', 'VIEWER'), u.name ASC`,
    [projectId]
  );
  return rows.map(mapMember);
}

export async function add(project, { userId, roleId }) {
  assertProjectActive(project);
  const role = await assertProjectRole(roleId);

  const user = await queryOne('SELECT id, name FROM users WHERE id = ? AND deleted_at IS NULL AND is_active = 1', [userId]);
  if (!user) throw new NotFoundError('User not found or inactive', 'USER_NOT_FOUND');

  const existing = await queryOne('SELECT id, deleted_at FROM project_members WHERE project_id = ? AND user_id = ?', [project.id, userId]);
  if (existing && !existing.deleted_at) throw new ConflictError('This user is already a member of the project', 'ALREADY_MEMBER');

  const actorId = getCurrentUserId();
  await transaction(async (conn) => {
    if (existing) {
      // Previously removed -> restore the soft-deleted row with the new role.
      await query(
        'UPDATE project_members SET deleted_at = NULL, deleted_by = NULL, role_id = ?, updated_by = ? WHERE id = ?',
        [roleId, actorId, existing.id],
        conn
      );
    } else {
      await query(
        'INSERT INTO project_members (project_id, user_id, role_id, created_by, updated_by) VALUES (?, ?, ?, ?, ?)',
        [project.id, userId, roleId, actorId, actorId],
        conn
      );
    }
    await auditService.log({
      action: AUDIT_ACTION.MEMBER_ADDED,
      entityType: ENTITY.MEMBER,
      entityId: userId,
      changes: { member: { from: null, to: user.name }, role: { from: null, to: role.name } },
      conn,
    });
  });
  return mapMember(await getMemberOrFail(project.id, userId));
}

export async function changeRole(project, userId, roleId) {
  assertProjectActive(project);
  const role = await assertProjectRole(roleId);
  const member = await getMemberOrFail(project.id, userId);

  if (member.role_id === roleId) return mapMember(member);
  if (role.name !== PROJECT_ROLES.OWNER) await assertNotLastOwner(project.id, member);

  await transaction(async (conn) => {
    await query(
      'UPDATE project_members SET role_id = ?, updated_by = ? WHERE project_id = ? AND user_id = ? AND deleted_at IS NULL',
      [roleId, getCurrentUserId(), project.id, userId],
      conn
    );
    await auditService.log({
      action: AUDIT_ACTION.MEMBER_ROLE_CHANGED,
      entityType: ENTITY.MEMBER,
      entityId: userId,
      changes: { member: { from: member.name, to: member.name }, role: { from: member.role_name, to: role.name } },
      conn,
    });
  });
  return mapMember(await getMemberOrFail(project.id, userId));
}

export async function remove(project, userId) {
  assertProjectActive(project);
  const member = await getMemberOrFail(project.id, userId);
  await assertNotLastOwner(project.id, member);

  const actorId = getCurrentUserId();
  await transaction(async (conn) => {
    // Their open work goes back to "unassigned" instead of pointing at a non-member.
    await query(
      'UPDATE tasks SET assignee_id = NULL, updated_by = ? WHERE project_id = ? AND assignee_id = ? AND deleted_at IS NULL',
      [actorId, project.id, userId],
      conn
    );
    await query(
      'UPDATE project_members SET deleted_at = UTC_TIMESTAMP(), deleted_by = ? WHERE project_id = ? AND user_id = ? AND deleted_at IS NULL',
      [actorId, project.id, userId],
      conn
    );
    await auditService.log({
      action: AUDIT_ACTION.MEMBER_REMOVED,
      entityType: ENTITY.MEMBER,
      entityId: userId,
      changes: { member: { from: member.name, to: null }, role: { from: member.role_name, to: null } },
      conn,
    });
  });
}
