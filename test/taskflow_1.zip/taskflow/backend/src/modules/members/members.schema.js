import { z } from 'zod';
import { idSchema } from '../../utils/schemas.js';

export const projectParams = z.object({ projectId: idSchema });
export const memberParams = z.object({ projectId: idSchema, userId: idSchema });

export const addMemberBody = z.object({ userId: idSchema, roleId: idSchema });
export const changeRoleBody = z.object({ roleId: idSchema });
