import { Router } from 'express';
import { sendCreated, sendSuccess } from '../../utils/apiResponse.js';
import { PERMISSIONS } from '../../constants/index.js';
import { validate } from '../../middleware/validate.js';
import { projectAccess } from '../../middleware/projectAccess.js';
import * as membersService from './members.service.js';
import { addMemberBody, changeRoleBody, memberParams, projectParams } from './members.schema.js';

// Mounted at /projects/:projectId/members behind `authenticate`.
const router = Router({ mergeParams: true });

router.get('/', validate({ params: projectParams }), projectAccess(PERMISSIONS.PROJECT_READ), async (req, res) => {
  const data = await membersService.list(req.project.id);
  return sendSuccess(res, { message: 'Members fetched', data });
});

router.post(
  '/',
  validate({ params: projectParams, body: addMemberBody }),
  projectAccess(PERMISSIONS.PROJECT_MANAGE_MEMBERS),
  async (req, res) => {
    const data = await membersService.add(req.project, req.body);
    return sendCreated(res, { message: 'Member added', data });
  }
);

router.put(
  '/:userId',
  validate({ params: memberParams, body: changeRoleBody }),
  projectAccess(PERMISSIONS.PROJECT_MANAGE_MEMBERS),
  async (req, res) => {
    const data = await membersService.changeRole(req.project, req.params.userId, req.body.roleId);
    return sendSuccess(res, { message: 'Member role updated', data });
  }
);

router.delete(
  '/:userId',
  validate({ params: memberParams }),
  projectAccess(PERMISSIONS.PROJECT_MANAGE_MEMBERS),
  async (req, res) => {
    await membersService.remove(req.project, req.params.userId);
    return sendSuccess(res, { message: 'Member removed' });
  }
);

export default router;
