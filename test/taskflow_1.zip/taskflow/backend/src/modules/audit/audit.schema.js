import { z } from 'zod';
import { idSchema, pageQuery } from '../../utils/schemas.js';

export const projectParams = z.object({ projectId: idSchema });

export const listAuditQuery = z.object({
  ...pageQuery,
  entityType: z.string().trim().max(40).optional(),
  entityId: idSchema.optional(),
  userId: idSchema.optional(),
  action: z.string().trim().max(60).optional(),
  projectId: idSchema.optional(),
});
