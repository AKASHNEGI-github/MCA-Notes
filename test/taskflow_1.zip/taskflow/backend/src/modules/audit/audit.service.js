import { query } from '../../config/db.js';
import { getContextValue, getCurrentUserId, getRequestId } from '../../utils/requestContext.js';
import { buildMeta, getPagination } from '../../utils/pagination.js';

/**
 * Write one row to the audit ledger.
 * Actor, request id, ip and user-agent come from the request context store, and
 * `projectId` falls back to the project resolved by the projectAccess middleware.
 * Pass `conn` so the log row is committed (or rolled back) with the business change.
 */
export async function log({ action, entityType, entityId = null, projectId, changes = null, metadata = null, userId, conn = null }) {
  await query(
    `INSERT INTO audit_logs
       (request_id, user_id, project_id, entity_type, entity_id, action, changes, metadata, ip, user_agent)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      getRequestId(),
      userId !== undefined ? userId : getCurrentUserId(),
      projectId !== undefined ? projectId : getContextValue('projectId') ?? null,
      entityType,
      entityId,
      action,
      changes ? JSON.stringify(changes) : null,
      metadata ? JSON.stringify(metadata) : null,
      getContextValue('ip') ?? null,
      (getContextValue('userAgent') ?? '').slice(0, 255) || null,
    ],
    conn
  );
}

const mapLog = (row) => ({
  id: row.id,
  action: row.action,
  entityType: row.entity_type,
  entityId: row.entity_id,
  projectId: row.project_id,
  projectName: row.project_name ?? null,
  changes: row.changes ?? null,
  metadata: row.metadata ?? null,
  requestId: row.request_id,
  ip: row.ip,
  createdAt: row.created_at,
  actor: row.user_id ? { id: row.user_id, name: row.user_name } : null,
});

/** Filtered, paginated read of the ledger (project feed, task timeline, admin view). */
export async function list(filters = {}) {
  const { page, limit, offset } = getPagination(filters);
  const where = ['1 = 1'];
  const params = [];

  if (filters.projectId) { where.push('a.project_id = ?'); params.push(filters.projectId); }
  if (filters.entityType) { where.push('a.entity_type = ?'); params.push(filters.entityType); }
  if (filters.entityId) { where.push('a.entity_id = ?'); params.push(filters.entityId); }
  if (filters.userId) { where.push('a.user_id = ?'); params.push(filters.userId); }
  if (filters.action) { where.push('a.action = ?'); params.push(filters.action); }

  const [{ total }] = await query(`SELECT COUNT(*) AS total FROM audit_logs a WHERE ${where.join(' AND ')}`, params);

  const rows = await query(
    `SELECT a.*, u.name AS user_name, p.name AS project_name
       FROM audit_logs a
       LEFT JOIN users u ON u.id = a.user_id
       LEFT JOIN projects p ON p.id = a.project_id
      WHERE ${where.join(' AND ')}
      ORDER BY a.id DESC
      LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );

  return { items: rows.map(mapLog), meta: buildMeta({ page, limit, total }) };
}
