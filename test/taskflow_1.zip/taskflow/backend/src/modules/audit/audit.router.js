import { Router } from 'express';
import { sendSuccess } from '../../utils/apiResponse.js';
import { PERMISSIONS } from '../../constants/index.js';
import { validate } from '../../middleware/validate.js';
import { projectAccess } from '../../middleware/projectAccess.js';
import * as auditService from './audit.service.js';
import { listAuditQuery, projectParams } from './audit.schema.js';

// Mounted at /projects/:projectId/activity
const router = Router({ mergeParams: true });

router.get(
  '/',
  validate({ params: projectParams, query: listAuditQuery }),
  projectAccess(PERMISSIONS.AUDIT_READ),
  async (req, res) => {
    const { items, meta } = await auditService.list({ ...req.query, projectId: req.project.id });
    return sendSuccess(res, { message: 'Project activity fetched', data: items, meta });
  }
);

export default router;
