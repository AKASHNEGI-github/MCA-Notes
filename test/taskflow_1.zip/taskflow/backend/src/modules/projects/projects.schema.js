import { z } from 'zod';
import { PROJECT_STATUS } from '../../constants/index.js';
import { dateSchema, idSchema, pageQuery } from '../../utils/schemas.js';

export const projectIdParams = z.object({ projectId: idSchema });

const projectName = z.string().trim().min(2, 'Name must be at least 2 characters').max(150, 'Name is too long');
const description = z.string().trim().max(5000, 'Description is too long').nullable();

const endAfterStart = (v) => !v.startDate || !v.endDate || v.endDate >= v.startDate;
const dateOrderIssue = { path: ['endDate'], message: 'End date cannot be before the start date' };

export const createProjectBody = z
  .object({
    name: projectName,
    description: description.optional(),
    startDate: dateSchema.nullable().optional(),
    endDate: dateSchema.nullable().optional(),
  })
  .refine(endAfterStart, dateOrderIssue);

export const updateProjectBody = z
  .object({
    name: projectName.optional(),
    description: description.optional(),
    status: z.enum(PROJECT_STATUS).optional(),
    startDate: dateSchema.nullable().optional(),
    endDate: dateSchema.nullable().optional(),
  })
  .refine((v) => Object.values(v).some((x) => x !== undefined), { message: 'Provide at least one field to update' })
  .refine(endAfterStart, dateOrderIssue);

export const listProjectsQuery = z.object({
  ...pageQuery,
  search: z.string().trim().max(100).optional(),
  status: z.enum(PROJECT_STATUS).optional(),
});
