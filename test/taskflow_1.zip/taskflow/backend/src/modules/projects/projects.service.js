import { query, queryOne, transaction } from '../../config/db.js';
import { AUDIT_ACTION, ENTITY, PERMISSIONS, PROJECT_ROLES } from '../../constants/index.js';
import { BadRequestError, NotFoundError } from '../../utils/errors.js';
import { getCurrentUser, getCurrentUserId } from '../../utils/requestContext.js';
import { buildMeta, getPagination } from '../../utils/pagination.js';
import { diffFields } from '../../utils/diff.js';
import * as auditService from '../audit/audit.service.js';

const mapProject = (row) => ({
  id: row.id,
  name: row.name,
  description: row.description,
  status: row.status,
  startDate: row.start_date,
  endDate: row.end_date,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

const mapListItem = (row) => ({
  ...mapProject(row),
  myRole: row.my_role ?? null,
  memberCount: row.member_count,
  taskCount: row.task_count,
  doneCount: row.done_count,
});

/** Projects the caller can see: their memberships, or every project for `project:read-all`. */
export async function list(filters = {}) {
  const user = getCurrentUser();
  const seeAll = user.permissions.has(PERMISSIONS.PROJECT_READ_ALL) ? 1 : 0;
  const { page, limit, offset } = getPagination(filters);

  const where = ['p.deleted_at IS NULL', '(? = 1 OR me.role_name IS NOT NULL)'];
  const params = [seeAll];
  if (filters.search) {
    where.push('(p.name LIKE ? OR p.description LIKE ?)');
    params.push(`%${filters.search}%`, `%${filters.search}%`);
  }
  if (filters.status) { where.push('p.status = ?'); params.push(filters.status); }

  const myRoleJoin = `
    LEFT JOIN (
      SELECT pm.project_id, r.name AS role_name
        FROM project_members pm
        JOIN roles r ON r.id = pm.role_id
       WHERE pm.user_id = ? AND pm.deleted_at IS NULL
    ) me ON me.project_id = p.id`;

  const [{ total }] = await query(
    `SELECT COUNT(*) AS total FROM projects p ${myRoleJoin} WHERE ${where.join(' AND ')}`,
    [user.id, ...params]
  );

  const rows = await query(
    `SELECT p.*, me.role_name AS my_role,
            (SELECT COUNT(*) FROM project_members m WHERE m.project_id = p.id AND m.deleted_at IS NULL) AS member_count,
            (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.deleted_at IS NULL) AS task_count,
            (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.deleted_at IS NULL AND t.status = 'DONE') AS done_count
       FROM projects p ${myRoleJoin}
      WHERE ${where.join(' AND ')}
      ORDER BY p.status ASC, p.updated_at DESC, p.id DESC
      LIMIT ? OFFSET ?`,
    [user.id, ...params, limit, offset]
  );

  return { items: rows.map(mapListItem), meta: buildMeta({ page, limit, total }) };
}

/** `project` / `access` come from the projectAccess middleware. */
export async function getDetails(project, access) {
  const counts = await queryOne(
    `SELECT (SELECT COUNT(*) FROM project_members m WHERE m.project_id = ? AND m.deleted_at IS NULL) AS member_count,
            (SELECT COUNT(*) FROM tasks t WHERE t.project_id = ? AND t.deleted_at IS NULL) AS task_count,
            (SELECT COUNT(*) FROM tasks t WHERE t.project_id = ? AND t.deleted_at IS NULL AND t.status = 'DONE') AS done_count`,
    [project.id, project.id, project.id]
  );
  return {
    ...mapProject(project),
    memberCount: counts.member_count,
    taskCount: counts.task_count,
    doneCount: counts.done_count,
    myRole: access.role,
    permissions: [...access.permissions].sort(),
  };
}

async function loadDetails(projectId) {
  const project = await queryOne('SELECT * FROM projects WHERE id = ? AND deleted_at IS NULL', [projectId]);
  if (!project) throw new NotFoundError('Project not found', 'PROJECT_NOT_FOUND');
  return project;
}

export async function create(input) {
  const actorId = getCurrentUserId();
  const ownerRole = await queryOne(
    "SELECT id FROM roles WHERE scope = 'PROJECT' AND name = ? AND deleted_at IS NULL",
    [PROJECT_ROLES.OWNER]
  );

  // Project + owner membership + audit row succeed or fail together.
  const projectId = await transaction(async (conn) => {
    const result = await query(
      `INSERT INTO projects (name, description, start_date, end_date, created_by, updated_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [input.name, input.description ?? null, input.startDate ?? null, input.endDate ?? null, actorId, actorId],
      conn
    );
    await query(
      'INSERT INTO project_members (project_id, user_id, role_id, created_by, updated_by) VALUES (?, ?, ?, ?, ?)',
      [result.insertId, actorId, ownerRole.id, actorId, actorId],
      conn
    );
    await auditService.log({
      action: AUDIT_ACTION.PROJECT_CREATED,
      entityType: ENTITY.PROJECT,
      entityId: result.insertId,
      projectId: result.insertId,
      metadata: { name: input.name },
      conn,
    });
    return result.insertId;
  });

  return mapListItem({ ...(await loadDetails(projectId)), my_role: PROJECT_ROLES.OWNER, member_count: 1, task_count: 0, done_count: 0 });
}

export async function update(project, access, input) {
  const next = {
    name: input.name ?? project.name,
    description: input.description === undefined ? project.description : input.description,
    status: input.status ?? project.status,
    start_date: input.startDate === undefined ? project.start_date : input.startDate,
    end_date: input.endDate === undefined ? project.end_date : input.endDate,
  };
  if (next.start_date && next.end_date && next.end_date < next.start_date) {
    throw new BadRequestError('End date cannot be before the start date', 'INVALID_DATE_RANGE');
  }

  const changes = diffFields(project, next, ['name', 'description', 'status', 'start_date', 'end_date']);
  if (Object.keys(changes).length) {
    await transaction(async (conn) => {
      await query(
        `UPDATE projects SET name = ?, description = ?, status = ?, start_date = ?, end_date = ?, updated_by = ?
          WHERE id = ?`,
        [next.name, next.description, next.status, next.start_date, next.end_date, getCurrentUserId(), project.id],
        conn
      );

      const { status: statusChange, ...otherChanges } = changes;
      if (statusChange) {
        await auditService.log({
          action: statusChange.to === 'ARCHIVED' ? AUDIT_ACTION.PROJECT_ARCHIVED : AUDIT_ACTION.PROJECT_RESTORED,
          entityType: ENTITY.PROJECT,
          entityId: project.id,
          changes: { status: statusChange },
          conn,
        });
      }
      if (Object.keys(otherChanges).length) {
        await auditService.log({
          action: AUDIT_ACTION.PROJECT_UPDATED,
          entityType: ENTITY.PROJECT,
          entityId: project.id,
          changes: otherChanges,
          conn,
        });
      }
    });
  }
  return getDetails(await loadDetails(project.id), access);
}

/** Soft delete cascades to the project's members, tasks and comments in one transaction. */
export async function remove(project) {
  const actorId = getCurrentUserId();
  await transaction(async (conn) => {
    for (const table of ['comments', 'tasks', 'project_members']) {
      await query(
        `UPDATE ${table} SET deleted_at = UTC_TIMESTAMP(), deleted_by = ? WHERE project_id = ? AND deleted_at IS NULL`,
        [actorId, project.id],
        conn
      );
    }
    await query('UPDATE projects SET deleted_at = UTC_TIMESTAMP(), deleted_by = ? WHERE id = ?', [actorId, project.id], conn);
    await auditService.log({
      action: AUDIT_ACTION.PROJECT_DELETED,
      entityType: ENTITY.PROJECT,
      entityId: project.id,
      metadata: { name: project.name },
      conn,
    });
  });
}
