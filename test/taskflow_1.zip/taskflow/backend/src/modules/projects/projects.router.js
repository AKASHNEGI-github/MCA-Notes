import { Router } from 'express';
import { sendCreated, sendSuccess } from '../../utils/apiResponse.js';
import { PERMISSIONS } from '../../constants/index.js';
import { validate } from '../../middleware/validate.js';
import { authorize } from '../../middleware/authorize.js';
import { projectAccess } from '../../middleware/projectAccess.js';
import * as projectsService from './projects.service.js';
import * as adminService from '../admin/admin.service.js';
import { createProjectBody, listProjectsQuery, projectIdParams, updateProjectBody } from './projects.schema.js';

// Mounted at /projects behind `authenticate`.
const router = Router();

// Project roles (OWNER / EDITOR / VIEWER) for member pickers. Must stay above /:projectId.
router.get('/roles', async (req, res) => {
  const data = await adminService.listRoles({ scope: 'PROJECT' });
  return sendSuccess(res, { message: 'Project roles fetched', data });
});

router.get('/', validate({ query: listProjectsQuery }), async (req, res) => {
  const { items, meta } = await projectsService.list(req.query);
  return sendSuccess(res, { message: 'Projects fetched', data: items, meta });
});

router.post('/', authorize(PERMISSIONS.PROJECT_CREATE), validate({ body: createProjectBody }), async (req, res) => {
  const data = await projectsService.create(req.body);
  return sendCreated(res, { message: 'Project created', data });
});

router.get('/:projectId', validate({ params: projectIdParams }), projectAccess(PERMISSIONS.PROJECT_READ), async (req, res) => {
  const data = await projectsService.getDetails(req.project, req.projectAccess);
  return sendSuccess(res, { message: 'Project fetched', data });
});

router.put(
  '/:projectId',
  validate({ params: projectIdParams, body: updateProjectBody }),
  projectAccess(PERMISSIONS.PROJECT_UPDATE),
  async (req, res) => {
    const data = await projectsService.update(req.project, req.projectAccess, req.body);
    return sendSuccess(res, { message: 'Project updated', data });
  }
);

router.delete('/:projectId', validate({ params: projectIdParams }), projectAccess(PERMISSIONS.PROJECT_DELETE), async (req, res) => {
  await projectsService.remove(req.project);
  return sendSuccess(res, { message: 'Project deleted' });
});


export default router;
