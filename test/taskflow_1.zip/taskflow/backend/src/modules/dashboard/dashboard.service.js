import { query, queryOne } from '../../config/db.js';
import { getCurrentUserId } from '../../utils/requestContext.js';
import { TASK_PRIORITY, TASK_STATUS } from '../../constants/index.js';
import { TASK_SELECT, mapTask } from '../tasks/tasks.service.js';
import * as projectsService from '../projects/projects.service.js';

const MEMBER_OF_PROJECT = `EXISTS (SELECT 1 FROM project_members pm
                                   WHERE pm.project_id = t.project_id AND pm.user_id = ? AND pm.deleted_at IS NULL)`;

/** Personal dashboard: my workload, what is due soon / late, and my most recent projects. */
export async function getMine() {
  const userId = getCurrentUserId();

  const stats = await queryOne(
    `SELECT COUNT(*) AS total,
            COUNT(CASE WHEN t.status = 'TODO' THEN 1 END) AS todo,
            COUNT(CASE WHEN t.status = 'IN_PROGRESS' THEN 1 END) AS in_progress,
            COUNT(CASE WHEN t.status = 'IN_REVIEW' THEN 1 END) AS in_review,
            COUNT(CASE WHEN t.status = 'DONE' THEN 1 END) AS done,
            COUNT(CASE WHEN t.status <> 'DONE' AND t.due_date < UTC_DATE() THEN 1 END) AS overdue,
            COUNT(CASE WHEN t.status <> 'DONE' AND t.due_date BETWEEN UTC_DATE() AND DATE_ADD(UTC_DATE(), INTERVAL 7 DAY) THEN 1 END) AS due_soon
       FROM tasks t
       JOIN projects p ON p.id = t.project_id AND p.deleted_at IS NULL
      WHERE t.deleted_at IS NULL AND t.assignee_id = ? AND ${MEMBER_OF_PROJECT}`,
    [userId, userId]
  );

  const upcoming = await query(
    `${TASK_SELECT}
      WHERE t.deleted_at IS NULL AND t.assignee_id = ? AND ${MEMBER_OF_PROJECT}
        AND t.status <> 'DONE' AND t.due_date >= UTC_DATE()
      ORDER BY t.due_date ASC, t.id DESC LIMIT 6`,
    [userId, userId]
  );
  const overdue = await query(
    `${TASK_SELECT}
      WHERE t.deleted_at IS NULL AND t.assignee_id = ? AND ${MEMBER_OF_PROJECT}
        AND t.status <> 'DONE' AND t.due_date < UTC_DATE()
      ORDER BY t.due_date ASC, t.id DESC LIMIT 6`,
    [userId, userId]
  );
  const { items: projects, meta } = await projectsService.list({ page: 1, limit: 6 });

  return {
    stats: {
      assigned: stats.total,
      todo: stats.todo,
      inProgress: stats.in_progress,
      inReview: stats.in_review,
      done: stats.done,
      overdue: stats.overdue,
      dueSoon: stats.due_soon,
    },
    upcoming: upcoming.map((r) => mapTask(r)),
    overdue: overdue.map((r) => mapTask(r)),
    projects,
    projectCount: meta.total,
  };
}

/** Per-project dashboard: progress, breakdowns and workload per assignee. */
export async function getForProject(project) {
  const byStatusRows = await query(
    'SELECT status, COUNT(*) AS count FROM tasks WHERE project_id = ? AND deleted_at IS NULL GROUP BY status',
    [project.id]
  );
  const byPriorityRows = await query(
    'SELECT priority, COUNT(*) AS count FROM tasks WHERE project_id = ? AND deleted_at IS NULL GROUP BY priority',
    [project.id]
  );
  const workload = await query(
    `SELECT u.id, u.name, COUNT(*) AS open_tasks
       FROM tasks t
       JOIN users u ON u.id = t.assignee_id
      WHERE t.project_id = ? AND t.deleted_at IS NULL AND t.status <> 'DONE'
      GROUP BY u.id, u.name
      ORDER BY open_tasks DESC, u.name ASC
      LIMIT 8`,
    [project.id]
  );
  const extra = await queryOne(
    `SELECT COUNT(CASE WHEN status <> 'DONE' AND due_date < UTC_DATE() THEN 1 END) AS overdue,
            COUNT(CASE WHEN assignee_id IS NULL AND status <> 'DONE' THEN 1 END) AS unassigned,
            (SELECT COUNT(*) FROM project_members m WHERE m.project_id = ? AND m.deleted_at IS NULL) AS members
       FROM tasks WHERE project_id = ? AND deleted_at IS NULL`,
    [project.id, project.id]
  );

  const byStatus = Object.fromEntries(TASK_STATUS.map((s) => [s, 0]));
  byStatusRows.forEach((r) => { byStatus[r.status] = r.count; });
  const byPriority = Object.fromEntries(TASK_PRIORITY.map((p) => [p, 0]));
  byPriority.LOW = 0;
  byPriorityRows.forEach((r) => { byPriority[r.priority] = r.count; });

  const total = Object.values(byStatus).reduce((a, b) => a + b, 0);
  return {
    total,
    completionPercent: total ? Math.round((byStatus.DONE / total) * 100) : 0,
    overdue: extra.overdue,
    unassigned: extra.unassigned,
    members: extra.members,
    byStatus,
    byPriority,
    workload: workload.map((w) => ({ userId: w.id, name: w.name, openTasks: w.open_tasks })),
  };
}
