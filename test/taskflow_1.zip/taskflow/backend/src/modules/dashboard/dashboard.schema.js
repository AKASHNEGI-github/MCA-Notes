import { z } from 'zod';
import { idSchema } from '../../utils/schemas.js';

export const projectParams = z.object({ projectId: idSchema });
