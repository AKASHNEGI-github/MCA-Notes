import { Router } from 'express';
import { sendSuccess } from '../../utils/apiResponse.js';
import { PERMISSIONS } from '../../constants/index.js';
import { validate } from '../../middleware/validate.js';
import { projectAccess } from '../../middleware/projectAccess.js';
import * as dashboardService from './dashboard.service.js';
import { projectParams } from './dashboard.schema.js';

// Mounted at /dashboard behind `authenticate`.
const router = Router();

router.get('/', async (req, res) => {
  const data = await dashboardService.getMine();
  return sendSuccess(res, { message: 'Dashboard fetched', data });
});

router.get(
  '/projects/:projectId',
  validate({ params: projectParams }),
  projectAccess(PERMISSIONS.PROJECT_READ),
  async (req, res) => {
    const data = await dashboardService.getForProject(req.project);
    return sendSuccess(res, { message: 'Project dashboard fetched', data });
  }
);

export default router;
