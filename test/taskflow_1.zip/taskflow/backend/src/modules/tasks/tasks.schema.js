import { z } from 'zod';
import { TASK_PRIORITY, TASK_STATUS } from '../../constants/index.js';
import { booleanQuery, dateSchema, idSchema, pageQuery } from '../../utils/schemas.js';

export const projectParams = z.object({ projectId: idSchema });
export const taskParams = z.object({ projectId: idSchema, taskId: idSchema });

const title = z.string().trim().min(2, 'Title must be at least 2 characters').max(200, 'Title is too long');
const description = z.string().trim().max(10000, 'Description is too long').nullable();

export const createTaskBody = z.object({
  title,
  description: description.optional(),
  status: z.enum(TASK_STATUS).optional(),
  priority: z.enum(TASK_PRIORITY).optional(),
  assigneeId: idSchema.nullable().optional(),
  dueDate: dateSchema.nullable().optional(),
});

export const updateTaskBody = z
  .object({
    title: title.optional(),
    description: description.optional(),
    status: z.enum(TASK_STATUS).optional(),
    priority: z.enum(TASK_PRIORITY).optional(),
    assigneeId: idSchema.nullable().optional(),
    dueDate: dateSchema.nullable().optional(),
  })
  .refine((v) => Object.values(v).some((x) => x !== undefined), { message: 'Provide at least one field to update' });

export const updateStatusBody = z.object({ status: z.enum(TASK_STATUS) });

const filters = {
  status: z.enum(TASK_STATUS).optional(),
  priority: z.enum(TASK_PRIORITY).optional(),
  search: z.string().trim().max(100).optional(),
  overdue: booleanQuery.optional(),
  dueFrom: dateSchema.optional(),
  dueTo: dateSchema.optional(),
  sortBy: z.enum(['createdAt', 'updatedAt', 'title', 'status', 'priority', 'dueDate']).default('createdAt'),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
  ...pageQuery,
};

export const listTasksQuery = z.object({
  ...filters,
  assigneeId: idSchema.optional(),
  unassigned: booleanQuery.optional(),
});

export const myTasksQuery = z.object(filters);

export const activityQuery = z.object({ ...pageQuery });
