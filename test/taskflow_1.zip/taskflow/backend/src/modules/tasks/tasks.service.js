import { query, queryOne, transaction } from '../../config/db.js';
import { AUDIT_ACTION, ENTITY, PERMISSIONS } from '../../constants/index.js';
import { BadRequestError, ConflictError, ForbiddenError, NotFoundError } from '../../utils/errors.js';
import { getCurrentUser, getCurrentUserId } from '../../utils/requestContext.js';
import { buildMeta, getPagination } from '../../utils/pagination.js';
import { diffFields } from '../../utils/diff.js';
import { mapUserBrief } from '../../utils/mappers.js';
import * as auditService from '../audit/audit.service.js';

/* ---------------------------- shared SQL / mapping ---------------------------- */

export const TASK_SELECT = `
  SELECT t.id, t.project_id, t.title, t.description, t.status, t.priority, t.assignee_id, t.due_date,
         t.completed_at, t.created_at, t.updated_at, t.created_by,
         (t.due_date IS NOT NULL AND t.due_date < UTC_DATE() AND t.status <> 'DONE') AS is_overdue,
         a.name AS assignee_name, c.name AS creator_name, p.name AS project_name,
         (SELECT COUNT(*) FROM comments cm WHERE cm.task_id = t.id AND cm.deleted_at IS NULL) AS comment_count
    FROM tasks t
    JOIN projects p ON p.id = t.project_id AND p.deleted_at IS NULL
    LEFT JOIN users a ON a.id = t.assignee_id
    LEFT JOIN users c ON c.id = t.created_by`;

export const mapTask = (row, access = null) => ({
  id: row.id,
  projectId: row.project_id,
  projectName: row.project_name,
  title: row.title,
  description: row.description,
  status: row.status,
  priority: row.priority,
  dueDate: row.due_date,
  isOverdue: Boolean(row.is_overdue),
  completedAt: row.completed_at,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
  commentCount: row.comment_count,
  assignee: mapUserBrief(row.assignee_id, row.assignee_name),
  createdBy: mapUserBrief(row.created_by, row.creator_name),
  ...(access && {
    canUpdate: canModifyTask(access, row),
    canDelete: access.can(PERMISSIONS.TASK_DELETE),
  }),
});

/**
 * Task-level RBAC: `task:update` edits any task, `task:update-own` only tasks the caller
 * created or is assigned to. This is the "permission depends on the resource" case.
 */
function canModifyTask(access, task) {
  if (access.can(PERMISSIONS.TASK_UPDATE)) return true;
  const userId = getCurrentUserId();
  return access.can(PERMISSIONS.TASK_UPDATE_OWN) && (task.assignee_id === userId || task.created_by === userId);
}

const assertProjectActive = (project) => {
  if (project.status === 'ARCHIVED') throw new ConflictError('This project is archived. Restore it to make changes.', 'PROJECT_ARCHIVED');
};

async function assertAssigneeIsMember(projectId, assigneeId) {
  if (assigneeId == null) return null;
  const member = await queryOne(
    `SELECT u.id, u.name
       FROM project_members pm
       JOIN users u ON u.id = pm.user_id AND u.deleted_at IS NULL AND u.is_active = 1
      WHERE pm.project_id = ? AND pm.user_id = ? AND pm.deleted_at IS NULL`,
    [projectId, assigneeId]
  );
  if (!member) throw new BadRequestError('Assignee must be an active member of the project', 'ASSIGNEE_NOT_MEMBER');
  return member;
}

const SORT_COLUMNS = {
  createdAt: 't.created_at',
  updatedAt: 't.updated_at',
  title: 't.title',
  status: "FIELD(t.status, 'TODO', 'IN_PROGRESS', 'IN_REVIEW', 'DONE')",
  priority: "FIELD(t.priority, 'LOW', 'MEDIUM', 'HIGH', 'URGENT')",
};

function buildOrderBy({ sortBy = 'createdAt', sortOrder = 'desc' }) {
  const dir = sortOrder === 'asc' ? 'ASC' : 'DESC';
  const primary = sortBy === 'dueDate' ? `t.due_date IS NULL, t.due_date ${dir}` : `${SORT_COLUMNS[sortBy]} ${dir}`;
  return `${primary}, t.id DESC`;
}

function applyFilters(filters, where, params) {
  if (filters.status) { where.push('t.status = ?'); params.push(filters.status); }
  if (filters.priority) { where.push('t.priority = ?'); params.push(filters.priority); }
  if (filters.search) { where.push('t.title LIKE ?'); params.push(`%${filters.search}%`); }
  if (filters.dueFrom) { where.push('t.due_date >= ?'); params.push(filters.dueFrom); }
  if (filters.dueTo) { where.push('t.due_date <= ?'); params.push(filters.dueTo); }
  if (filters.overdue === true) where.push("t.due_date < UTC_DATE() AND t.status <> 'DONE'");
  if (filters.assigneeId) { where.push('t.assignee_id = ?'); params.push(filters.assigneeId); }
  if (filters.unassigned === true) where.push('t.assignee_id IS NULL');
}

async function runList(whereBase, paramsBase, filters, access = null) {
  const where = [...whereBase];
  const params = [...paramsBase];
  applyFilters(filters, where, params);
  const { page, limit, offset } = getPagination(filters);

  const [{ total }] = await query(
    `SELECT COUNT(*) AS total FROM tasks t JOIN projects p ON p.id = t.project_id AND p.deleted_at IS NULL WHERE ${where.join(' AND ')}`,
    params
  );
  const rows = await query(
    `${TASK_SELECT} WHERE ${where.join(' AND ')} ORDER BY ${buildOrderBy(filters)} LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );
  return { items: rows.map((r) => mapTask(r, access)), meta: buildMeta({ page, limit, total }) };
}

/* -------------------------------- queries -------------------------------- */

export const listForProject = (projectId, filters, access) =>
  runList(['t.deleted_at IS NULL', 't.project_id = ?'], [projectId], filters, access);

/** Tasks assigned to the caller, across every project they still belong to. */
export const listMine = (filters) =>
  runList(
    [
      't.deleted_at IS NULL',
      't.assignee_id = ?',
      `EXISTS (SELECT 1 FROM project_members pm
                WHERE pm.project_id = t.project_id AND pm.user_id = ? AND pm.deleted_at IS NULL)`,
    ],
    [getCurrentUserId(), getCurrentUserId()],
    filters
  );

async function fetchTaskRow(projectId, taskId, conn = null) {
  const row = await queryOne(`${TASK_SELECT} WHERE t.id = ? AND t.project_id = ? AND t.deleted_at IS NULL`, [taskId, projectId], conn);
  if (!row) throw new NotFoundError('Task not found', 'TASK_NOT_FOUND');
  return row;
}

export async function getOne(projectId, taskId, access) {
  return mapTask(await fetchTaskRow(projectId, taskId), access);
}

/* ------------------------------- commands ------------------------------- */

export async function create(project, access, input) {
  assertProjectActive(project);
  const assignee = await assertAssigneeIsMember(project.id, input.assigneeId);
  const actorId = getCurrentUserId();
  const status = input.status ?? 'TODO';

  const taskId = await transaction(async (conn) => {
    const result = await query(
      `INSERT INTO tasks (project_id, title, description, status, priority, assignee_id, due_date, completed_at, created_by, updated_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        project.id,
        input.title,
        input.description ?? null,
        status,
        input.priority ?? 'MEDIUM',
        input.assigneeId ?? null,
        input.dueDate ?? null,
        status === 'DONE' ? new Date() : null,
        actorId,
        actorId,
      ],
      conn
    );
    await auditService.log({
      action: AUDIT_ACTION.TASK_CREATED,
      entityType: ENTITY.TASK,
      entityId: result.insertId,
      metadata: { title: input.title, assignee: assignee?.name ?? null },
      conn,
    });
    return result.insertId;
  });
  return getOne(project.id, taskId, access);
}

const clip = (value) => (typeof value === 'string' && value.length > 120 ? `${value.slice(0, 120)}...` : value);

export async function update(project, access, taskId, input) {
  assertProjectActive(project);
  const before = await fetchTaskRow(project.id, taskId);

  if (!access.can(PERMISSIONS.TASK_UPDATE) && !access.can(PERMISSIONS.TASK_UPDATE_OWN)) {
    throw new ForbiddenError(`Missing permission: ${PERMISSIONS.TASK_UPDATE}`);
  }
  if (!canModifyTask(access, before)) {
    throw new ForbiddenError('You can only update tasks that you created or that are assigned to you', 'TASK_NOT_OWNED');
  }

  const assigneeChanging = input.assigneeId !== undefined && input.assigneeId !== before.assignee_id;
  const newAssignee = assigneeChanging ? await assertAssigneeIsMember(project.id, input.assigneeId) : null;

  const next = {
    title: input.title ?? before.title,
    description: input.description === undefined ? before.description : input.description,
    status: input.status ?? before.status,
    priority: input.priority ?? before.priority,
    assignee_id: input.assigneeId === undefined ? before.assignee_id : input.assigneeId,
    due_date: input.dueDate === undefined ? before.due_date : input.dueDate,
  };
  const changes = diffFields(before, next, ['title', 'description', 'status', 'priority', 'assignee_id', 'due_date']);
  if (!Object.keys(changes).length) return mapTask(before, access);

  // completed_at follows the status: set when it becomes DONE, cleared when it leaves DONE.
  let completedAt = before.completed_at;
  if (next.status === 'DONE' && before.status !== 'DONE') completedAt = new Date();
  if (next.status !== 'DONE') completedAt = null;

  await transaction(async (conn) => {
    await query(
      `UPDATE tasks SET title = ?, description = ?, status = ?, priority = ?, assignee_id = ?, due_date = ?,
              completed_at = ?, updated_by = ? WHERE id = ?`,
      [next.title, next.description, next.status, next.priority, next.assignee_id, next.due_date, completedAt, getCurrentUserId(), taskId],
      conn
    );

    const { status, assignee_id: assigneeChange, ...rest } = changes;
    const log = (action, diff) =>
      auditService.log({ action, entityType: ENTITY.TASK, entityId: taskId, changes: diff, conn });

    if (status) await log(AUDIT_ACTION.TASK_STATUS_CHANGED, { status });
    if (assigneeChange) {
      await log(AUDIT_ACTION.TASK_ASSIGNED, {
        assignee: { from: before.assignee_name ?? null, to: newAssignee?.name ?? null },
      });
    }
    if (Object.keys(rest).length) {
      const readable = Object.fromEntries(Object.entries(rest).map(([k, v]) => [k, { from: clip(v.from), to: clip(v.to) }]));
      await log(AUDIT_ACTION.TASK_UPDATED, readable);
    }
  });
  return getOne(project.id, taskId, access);
}

export async function remove(project, taskId) {
  assertProjectActive(project);
  const task = await fetchTaskRow(project.id, taskId);
  const actorId = getCurrentUserId();

  await transaction(async (conn) => {
    await query('UPDATE comments SET deleted_at = UTC_TIMESTAMP(), deleted_by = ? WHERE task_id = ? AND deleted_at IS NULL', [actorId, taskId], conn);
    await query('UPDATE tasks SET deleted_at = UTC_TIMESTAMP(), deleted_by = ? WHERE id = ?', [actorId, taskId], conn);
    await auditService.log({
      action: AUDIT_ACTION.TASK_DELETED,
      entityType: ENTITY.TASK,
      entityId: taskId,
      metadata: { title: task.title },
      conn,
    });
  });
}

/** Per-task timeline (anyone who can read tasks can see it). */
export async function activity(project, taskId, filters) {
  await fetchTaskRow(project.id, taskId);
  return auditService.list({ ...filters, projectId: project.id, entityType: ENTITY.TASK, entityId: taskId });
}
