import { Router } from 'express';
import { sendCreated, sendSuccess } from '../../utils/apiResponse.js';
import { PERMISSIONS } from '../../constants/index.js';
import { validate } from '../../middleware/validate.js';
import { projectAccess } from '../../middleware/projectAccess.js';
import * as tasksService from './tasks.service.js';
import {
  activityQuery,
  createTaskBody,
  listTasksQuery,
  myTasksQuery,
  projectParams,
  taskParams,
  updateStatusBody,
  updateTaskBody,
} from './tasks.schema.js';

// Mounted at /projects/:projectId/tasks behind `authenticate`.
const router = Router({ mergeParams: true });

router.get(
  '/',
  validate({ params: projectParams, query: listTasksQuery }),
  projectAccess(PERMISSIONS.TASK_READ),
  async (req, res) => {
    const { items, meta } = await tasksService.listForProject(req.project.id, req.query, req.projectAccess);
    return sendSuccess(res, { message: 'Tasks fetched', data: items, meta });
  }
);

router.post(
  '/',
  validate({ params: projectParams, body: createTaskBody }),
  projectAccess(PERMISSIONS.TASK_CREATE),
  async (req, res) => {
    const data = await tasksService.create(req.project, req.projectAccess, req.body);
    return sendCreated(res, { message: 'Task created', data });
  }
);

router.get('/:taskId', validate({ params: taskParams }), projectAccess(PERMISSIONS.TASK_READ), async (req, res) => {
  const data = await tasksService.getOne(req.project.id, req.params.taskId, req.projectAccess);
  return sendSuccess(res, { message: 'Task fetched', data });
});

// Needs task:update OR task:update-own; the service decides per task (ownership rule).
router.put(
  '/:taskId',
  validate({ params: taskParams, body: updateTaskBody }),
  projectAccess(),
  async (req, res) => {
    const data = await tasksService.update(req.project, req.projectAccess, req.params.taskId, req.body);
    return sendSuccess(res, { message: 'Task updated', data });
  }
);

router.patch(
  '/:taskId/status',
  validate({ params: taskParams, body: updateStatusBody }),
  projectAccess(),
  async (req, res) => {
    const data = await tasksService.update(req.project, req.projectAccess, req.params.taskId, { status: req.body.status });
    return sendSuccess(res, { message: 'Task status updated', data });
  }
);

router.delete('/:taskId', validate({ params: taskParams }), projectAccess(PERMISSIONS.TASK_DELETE), async (req, res) => {
  await tasksService.remove(req.project, req.params.taskId);
  return sendSuccess(res, { message: 'Task deleted' });
});

router.get(
  '/:taskId/activity',
  validate({ params: taskParams, query: activityQuery }),
  projectAccess(PERMISSIONS.TASK_READ),
  async (req, res) => {
    const { items, meta } = await tasksService.activity(req.project, req.params.taskId, req.query);
    return sendSuccess(res, { message: 'Task activity fetched', data: items, meta });
  }
);

// Mounted at /tasks behind `authenticate`: "My tasks" across projects.
export const myTasksRouter = Router();

myTasksRouter.get('/my', validate({ query: myTasksQuery }), async (req, res) => {
  const { items, meta } = await tasksService.listMine(req.query);
  return sendSuccess(res, { message: 'Your tasks fetched', data: items, meta });
});

export default router;
