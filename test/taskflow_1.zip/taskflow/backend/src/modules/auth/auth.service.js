import { randomUUID } from 'node:crypto';
import { query, queryOne, transaction } from '../../config/db.js';
import { env } from '../../config/env.js';
import { AUDIT_ACTION, ENTITY, GLOBAL_ROLES } from '../../constants/index.js';
import { BadRequestError, ConflictError, ForbiddenError, UnauthorizedError } from '../../utils/errors.js';
import { comparePassword, fakeCompare, hashPassword } from '../../utils/password.js';
import { generateRefreshToken, hashToken, signAccessToken } from '../../utils/tokens.js';
import { getContextValue, getCurrentUserId } from '../../utils/requestContext.js';
import { getRolePermissions } from '../../utils/permissions.js';
import * as auditService from '../audit/audit.service.js';

/* ----------------------------- helpers ----------------------------- */

/** User + global role + permissions. Used by the authenticate middleware and /auth/me. */
export async function getAuthUser(userId) {
  const row = await queryOne(
    `SELECT u.id, u.name, u.email, u.is_active, u.role_id, r.name AS role_name
       FROM users u
       JOIN roles r ON r.id = u.role_id AND r.deleted_at IS NULL
      WHERE u.id = ? AND u.deleted_at IS NULL`,
    [userId]
  );
  if (!row) return null;

  return {
    id: row.id,
    name: row.name,
    email: row.email,
    isActive: Boolean(row.is_active),
    role: { id: row.role_id, name: row.role_name },
    permissions: await getRolePermissions(row.role_id),
  };
}

/** JSON-safe version of an auth user (Set -> array). */
export const toPublicUser = (user) => ({
  id: user.id,
  name: user.name,
  email: user.email,
  role: user.role,
  permissions: [...user.permissions].sort(),
});

async function createRefreshToken(userId, familyId, conn = null) {
  const token = generateRefreshToken();
  const expiresAt = new Date(Date.now() + env.auth.refreshTtlDays * 24 * 60 * 60 * 1000);
  const result = await query(
    `INSERT INTO refresh_tokens (user_id, family_id, token_hash, expires_at, ip, user_agent)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [
      userId,
      familyId,
      hashToken(token),
      expiresAt,
      getContextValue('ip') ?? null,
      (getContextValue('userAgent') ?? '').slice(0, 255) || null,
    ],
    conn
  );
  return { id: result.insertId, token };
}

const tokenPayload = (accessToken, refreshToken) => ({
  accessToken,
  refreshToken,
  tokenType: 'Bearer',
  expiresIn: env.auth.accessTtl,
});

async function issueTokens(userId, conn = null) {
  const refresh = await createRefreshToken(userId, randomUUID(), conn);
  return tokenPayload(signAccessToken(userId), refresh.token);
}

const revokeAllTokens = (userId, conn = null) =>
  query('UPDATE refresh_tokens SET revoked_at = UTC_TIMESTAMP() WHERE user_id = ? AND revoked_at IS NULL', [userId], conn);

/* ----------------------------- use cases ----------------------------- */

export async function register({ name, email, password }) {
  // No deleted_at filter on purpose: a soft-deleted user's email stays reserved.
  const existing = await queryOne('SELECT id FROM users WHERE email = ?', [email]);
  if (existing) throw new ConflictError('An account with this email already exists', 'EMAIL_TAKEN');

  const role = await queryOne(
    "SELECT id FROM roles WHERE scope = 'GLOBAL' AND name = ? AND deleted_at IS NULL",
    [GLOBAL_ROLES.MEMBER]
  );
  const passwordHash = await hashPassword(password);

  const userId = await transaction(async (conn) => {
    const result = await query('INSERT INTO users (name, email, role_id) VALUES (?, ?, ?)', [name, email, role.id], conn);
    await query('INSERT INTO passwords (user_id, password_hash) VALUES (?, ?)', [result.insertId, passwordHash], conn);
    await auditService.log({
      action: AUDIT_ACTION.USER_REGISTERED,
      entityType: ENTITY.USER,
      entityId: result.insertId,
      userId: result.insertId,
      projectId: null,
      conn,
    });
    return result.insertId;
  });

  const user = await getAuthUser(userId);
  return { user: toPublicUser(user), ...(await issueTokens(userId)) };
}

export async function login({ email, password }) {
  const row = await queryOne(
    `SELECT u.id, u.is_active, pw.password_hash
       FROM users u
       LEFT JOIN passwords pw ON pw.user_id = u.id AND pw.deleted_at IS NULL
      WHERE u.email = ? AND u.deleted_at IS NULL`,
    [email]
  );

  let valid = false;
  if (row?.password_hash) valid = await comparePassword(password, row.password_hash);
  else await fakeCompare(password);

  if (!valid) throw new UnauthorizedError('Invalid email or password', 'INVALID_CREDENTIALS');
  if (!row.is_active) throw new ForbiddenError('Your account has been deactivated', 'ACCOUNT_DISABLED');

  await query('UPDATE users SET last_login_at = UTC_TIMESTAMP(), updated_at = updated_at WHERE id = ?', [row.id]);
  await auditService.log({
    action: AUDIT_ACTION.USER_LOGGED_IN,
    entityType: ENTITY.AUTH,
    entityId: row.id,
    userId: row.id,
    projectId: null,
  });

  const user = await getAuthUser(row.id);
  return { user: toPublicUser(user), ...(await issueTokens(row.id)) };
}

/**
 * Refresh-token rotation: every refresh returns a NEW refresh token and revokes the old one.
 * Presenting an already-revoked token means it leaked (or was replayed), so the whole
 * token family is revoked.
 */
export async function refresh(refreshToken) {
  const row = await queryOne('SELECT * FROM refresh_tokens WHERE token_hash = ?', [hashToken(refreshToken)]);
  if (!row) throw new UnauthorizedError('Refresh token is invalid', 'REFRESH_TOKEN_INVALID');

  if (row.revoked_at) {
    await query('UPDATE refresh_tokens SET revoked_at = UTC_TIMESTAMP() WHERE family_id = ? AND revoked_at IS NULL', [row.family_id]);
    await auditService.log({
      action: AUDIT_ACTION.TOKEN_REUSE_DETECTED,
      entityType: ENTITY.AUTH,
      entityId: row.user_id,
      userId: row.user_id,
      projectId: null,
    });
    throw new UnauthorizedError('Refresh token was already used. Please sign in again.', 'REFRESH_TOKEN_REUSED');
  }

  if (new Date(row.expires_at) < new Date()) {
    throw new UnauthorizedError('Refresh token has expired. Please sign in again.', 'REFRESH_TOKEN_EXPIRED');
  }

  const user = await getAuthUser(row.user_id);
  if (!user || !user.isActive) throw new UnauthorizedError('Account is not available', 'ACCOUNT_DISABLED');

  return transaction(async (conn) => {
    const next = await createRefreshToken(user.id, row.family_id, conn);
    const revoked = await query(
      'UPDATE refresh_tokens SET revoked_at = UTC_TIMESTAMP(), replaced_by_id = ? WHERE id = ? AND revoked_at IS NULL',
      [next.id, row.id],
      conn
    );
    if (revoked.affectedRows === 0) throw new UnauthorizedError('Refresh token was already used', 'REFRESH_TOKEN_REUSED');
    return { user: toPublicUser(user), ...tokenPayload(signAccessToken(user.id), next.token) };
  });
}

/** Idempotent: unknown / already revoked tokens are ignored. */
export async function logout(refreshToken) {
  const row = await queryOne('SELECT id, user_id FROM refresh_tokens WHERE token_hash = ?', [hashToken(refreshToken)]);
  if (!row) return;

  await query('UPDATE refresh_tokens SET revoked_at = UTC_TIMESTAMP() WHERE id = ? AND revoked_at IS NULL', [row.id]);
  await auditService.log({
    action: AUDIT_ACTION.USER_LOGGED_OUT,
    entityType: ENTITY.AUTH,
    entityId: row.user_id,
    userId: row.user_id,
    projectId: null,
  });
}

export async function logoutAll() {
  await revokeAllTokens(getCurrentUserId());
}

export async function getProfile() {
  const user = await getAuthUser(getCurrentUserId());
  return toPublicUser(user);
}

export async function changePassword({ currentPassword, newPassword }) {
  const userId = getCurrentUserId();
  const row = await queryOne('SELECT password_hash FROM passwords WHERE user_id = ? AND deleted_at IS NULL', [userId]);

  if (!row || !(await comparePassword(currentPassword, row.password_hash))) {
    throw new BadRequestError('Current password is incorrect', 'INVALID_CURRENT_PASSWORD');
  }

  const passwordHash = await hashPassword(newPassword);
  await transaction(async (conn) => {
    await query(
      'UPDATE passwords SET password_hash = ?, password_changed_at = UTC_TIMESTAMP() WHERE user_id = ? AND deleted_at IS NULL',
      [passwordHash, userId],
      conn
    );
    await revokeAllTokens(userId, conn); // sign out every other session
    await auditService.log({
      action: AUDIT_ACTION.PASSWORD_CHANGED,
      entityType: ENTITY.USER,
      entityId: userId,
      projectId: null,
      conn,
    });
  });

  const user = await getAuthUser(userId);
  return { user: toPublicUser(user), ...(await issueTokens(userId)) };
}
