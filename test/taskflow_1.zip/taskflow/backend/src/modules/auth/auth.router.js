import { Router } from 'express';
import { sendCreated, sendSuccess } from '../../utils/apiResponse.js';
import { validate } from '../../middleware/validate.js';
import { authenticate } from '../../middleware/authenticate.js';
import * as authService from './auth.service.js';
import { changePasswordBody, loginBody, refreshBody, registerBody } from './auth.schema.js';

const router = Router();

// ---- public ----
router.post('/register', validate({ body: registerBody }), async (req, res) => {
  const data = await authService.register(req.body);
  return sendCreated(res, { message: 'Account created successfully', data });
});

router.post('/login', validate({ body: loginBody }), async (req, res) => {
  const data = await authService.login(req.body);
  return sendSuccess(res, { message: 'Logged in successfully', data });
});

router.post('/refresh', validate({ body: refreshBody }), async (req, res) => {
  const data = await authService.refresh(req.body.refreshToken);
  return sendSuccess(res, { message: 'Token refreshed', data });
});

router.post('/logout', validate({ body: refreshBody }), async (req, res) => {
  await authService.logout(req.body.refreshToken);
  return sendSuccess(res, { message: 'Logged out successfully' });
});

// ---- authenticated ----
router.get('/me', authenticate, async (req, res) => {
  const data = await authService.getProfile();
  return sendSuccess(res, { message: 'Profile fetched', data });
});

router.put('/change-password', authenticate, validate({ body: changePasswordBody }), async (req, res) => {
  const data = await authService.changePassword(req.body);
  return sendSuccess(res, { message: 'Password changed. Other sessions were signed out.', data });
});

router.post('/logout-all', authenticate, async (req, res) => {
  await authService.logoutAll();
  return sendSuccess(res, { message: 'Signed out from all devices' });
});

export default router;
