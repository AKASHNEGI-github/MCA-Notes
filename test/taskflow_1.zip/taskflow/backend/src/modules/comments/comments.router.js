import { Router } from 'express';
import { sendCreated, sendSuccess } from '../../utils/apiResponse.js';
import { PERMISSIONS } from '../../constants/index.js';
import { validate } from '../../middleware/validate.js';
import { projectAccess } from '../../middleware/projectAccess.js';
import * as commentsService from './comments.service.js';
import { commentBody, commentParams, listCommentsQuery, taskParams } from './comments.schema.js';

// Mounted at /projects/:projectId/tasks/:taskId/comments behind `authenticate`.
const router = Router({ mergeParams: true });

router.get(
  '/',
  validate({ params: taskParams, query: listCommentsQuery }),
  projectAccess(PERMISSIONS.COMMENT_READ),
  async (req, res) => {
    const { items, meta } = await commentsService.list(req.project, req.projectAccess, req.params.taskId, req.query);
    return sendSuccess(res, { message: 'Comments fetched', data: items, meta });
  }
);

router.post(
  '/',
  validate({ params: taskParams, body: commentBody }),
  projectAccess(PERMISSIONS.COMMENT_CREATE),
  async (req, res) => {
    const data = await commentsService.create(req.project, req.projectAccess, req.params.taskId, req.body);
    return sendCreated(res, { message: 'Comment added', data });
  }
);

router.put(
  '/:commentId',
  validate({ params: commentParams, body: commentBody }),
  projectAccess(PERMISSIONS.COMMENT_READ),
  async (req, res) => {
    const data = await commentsService.update(req.project, req.projectAccess, req.params.taskId, req.params.commentId, req.body);
    return sendSuccess(res, { message: 'Comment updated', data });
  }
);

router.delete(
  '/:commentId',
  validate({ params: commentParams }),
  projectAccess(PERMISSIONS.COMMENT_READ),
  async (req, res) => {
    await commentsService.remove(req.project, req.projectAccess, req.params.taskId, req.params.commentId);
    return sendSuccess(res, { message: 'Comment deleted' });
  }
);

export default router;
