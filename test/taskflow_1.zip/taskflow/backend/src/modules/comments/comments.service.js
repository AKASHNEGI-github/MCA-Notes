import { query, queryOne, transaction } from '../../config/db.js';
import { AUDIT_ACTION, ENTITY, PERMISSIONS } from '../../constants/index.js';
import { ConflictError, ForbiddenError, NotFoundError } from '../../utils/errors.js';
import { getCurrentUserId } from '../../utils/requestContext.js';
import { buildMeta, getPagination } from '../../utils/pagination.js';
import * as auditService from '../audit/audit.service.js';

const COMMENT_SELECT = `
  SELECT c.id, c.task_id, c.author_id, c.body, c.created_at, c.updated_at, u.name AS author_name
    FROM comments c
    LEFT JOIN users u ON u.id = c.author_id`;

const mapComment = (row, access) => ({
  id: row.id,
  taskId: row.task_id,
  body: row.body,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
  isEdited: new Date(row.updated_at).getTime() - new Date(row.created_at).getTime() > 1000,
  author: { id: row.author_id, name: row.author_name },
  canEdit: row.author_id === getCurrentUserId(),
  canDelete: row.author_id === getCurrentUserId() || access.can(PERMISSIONS.COMMENT_DELETE),
});

async function assertTaskInProject(projectId, taskId) {
  const task = await queryOne('SELECT id FROM tasks WHERE id = ? AND project_id = ? AND deleted_at IS NULL', [taskId, projectId]);
  if (!task) throw new NotFoundError('Task not found', 'TASK_NOT_FOUND');
}

async function getCommentOrFail(projectId, taskId, commentId) {
  const row = await queryOne(
    `${COMMENT_SELECT} WHERE c.id = ? AND c.task_id = ? AND c.project_id = ? AND c.deleted_at IS NULL`,
    [commentId, taskId, projectId]
  );
  if (!row) throw new NotFoundError('Comment not found', 'COMMENT_NOT_FOUND');
  return row;
}

const assertProjectActive = (project) => {
  if (project.status === 'ARCHIVED') throw new ConflictError('This project is archived. Restore it to make changes.', 'PROJECT_ARCHIVED');
};

const preview = (text) => (text.length > 80 ? `${text.slice(0, 80)}...` : text);

export async function list(project, access, taskId, filters) {
  await assertTaskInProject(project.id, taskId);
  const { page, limit, offset } = getPagination(filters);

  const [{ total }] = await query(
    'SELECT COUNT(*) AS total FROM comments WHERE task_id = ? AND project_id = ? AND deleted_at IS NULL',
    [taskId, project.id]
  );
  const rows = await query(
    `${COMMENT_SELECT} WHERE c.task_id = ? AND c.project_id = ? AND c.deleted_at IS NULL
      ORDER BY c.created_at ASC, c.id ASC LIMIT ? OFFSET ?`,
    [taskId, project.id, limit, offset]
  );
  return { items: rows.map((r) => mapComment(r, access)), meta: buildMeta({ page, limit, total }) };
}

export async function create(project, access, taskId, { body }) {
  assertProjectActive(project);
  await assertTaskInProject(project.id, taskId);
  const actorId = getCurrentUserId();

  const commentId = await transaction(async (conn) => {
    const result = await query(
      'INSERT INTO comments (task_id, project_id, author_id, body, created_by, updated_by) VALUES (?, ?, ?, ?, ?, ?)',
      [taskId, project.id, actorId, body, actorId, actorId],
      conn
    );
    // Logged against the TASK so it shows up in the task's timeline.
    await auditService.log({
      action: AUDIT_ACTION.COMMENT_ADDED,
      entityType: ENTITY.TASK,
      entityId: taskId,
      metadata: { commentId: result.insertId, preview: preview(body) },
      conn,
    });
    return result.insertId;
  });
  return mapComment(await getCommentOrFail(project.id, taskId, commentId), access);
}

export async function update(project, access, taskId, commentId, { body }) {
  assertProjectActive(project);
  const comment = await getCommentOrFail(project.id, taskId, commentId);

  // Only the author may edit - even owners and admins cannot rewrite someone else's words.
  if (comment.author_id !== getCurrentUserId()) {
    throw new ForbiddenError('You can only edit your own comments', 'COMMENT_NOT_OWNED');
  }
  if (comment.body === body) return mapComment(comment, access);

  await transaction(async (conn) => {
    await query('UPDATE comments SET body = ?, updated_by = ? WHERE id = ?', [body, getCurrentUserId(), commentId], conn);
    await auditService.log({
      action: AUDIT_ACTION.COMMENT_UPDATED,
      entityType: ENTITY.TASK,
      entityId: taskId,
      metadata: { commentId, preview: preview(body) },
      conn,
    });
  });
  return mapComment(await getCommentOrFail(project.id, taskId, commentId), access);
}

export async function remove(project, access, taskId, commentId) {
  assertProjectActive(project);
  const comment = await getCommentOrFail(project.id, taskId, commentId);

  const isAuthor = comment.author_id === getCurrentUserId();
  if (!isAuthor && !access.can(PERMISSIONS.COMMENT_DELETE)) {
    throw new ForbiddenError('You can only delete your own comments', 'COMMENT_NOT_OWNED');
  }

  await transaction(async (conn) => {
    await query('UPDATE comments SET deleted_at = UTC_TIMESTAMP(), deleted_by = ? WHERE id = ?', [getCurrentUserId(), commentId], conn);
    await auditService.log({
      action: AUDIT_ACTION.COMMENT_DELETED,
      entityType: ENTITY.TASK,
      entityId: taskId,
      metadata: { commentId, preview: preview(comment.body) },
      conn,
    });
  });
}
