import { z } from 'zod';
import { idSchema, pageQuery } from '../../utils/schemas.js';

export const taskParams = z.object({ projectId: idSchema, taskId: idSchema });
export const commentParams = z.object({ projectId: idSchema, taskId: idSchema, commentId: idSchema });

const body = z.string().trim().min(1, 'Comment cannot be empty').max(5000, 'Comment is too long');

export const commentBody = z.object({ body });

export const listCommentsQuery = z.object({
  page: pageQuery.page,
  limit: z.coerce.number().int().min(1).max(100).default(50),
});
