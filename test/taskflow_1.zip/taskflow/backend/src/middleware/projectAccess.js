import { query, queryOne } from '../config/db.js';
import { ForbiddenError, NotFoundError } from '../utils/errors.js';
import { setContextValue } from '../utils/requestContext.js';
import { getRolePermissions, getScopePermissions } from '../utils/permissions.js';
import { PERMISSIONS } from '../constants/index.js';

/**
 * Project-level RBAC. Resolves the project from `:projectId`, finds the caller's
 * project role (OWNER / EDITOR / VIEWER) and its permissions, and optionally requires
 * some of them. Users holding the global `project:read-all` permission (admins) get
 * every project permission without needing a membership.
 *
 * Sets: req.project, req.projectAccess = { role, permissions, can(p) }
 */
export const projectAccess = (...required) => async (req, res, next) => {
  const projectId = Number(req.params.projectId);

  const project = await queryOne('SELECT * FROM projects WHERE id = ? AND deleted_at IS NULL', [projectId]);
  if (!project) throw new NotFoundError('Project not found', 'PROJECT_NOT_FOUND');

  const membership = await queryOne(
    `SELECT pm.role_id, r.name AS role_name
       FROM project_members pm
       JOIN roles r ON r.id = pm.role_id AND r.deleted_at IS NULL
      WHERE pm.project_id = ? AND pm.user_id = ? AND pm.deleted_at IS NULL`,
    [projectId, req.user.id]
  );

  let role = membership?.role_name ?? null;
  let permissions;

  if (req.user.permissions.has(PERMISSIONS.PROJECT_READ_ALL)) {
    permissions = await getScopePermissions('PROJECT');
    role = role ?? 'ADMIN';
  } else if (membership) {
    permissions = await getRolePermissions(membership.role_id);
  } else {
    throw new ForbiddenError('You are not a member of this project', 'NOT_PROJECT_MEMBER');
  }

  const missing = required.find((p) => !permissions.has(p));
  if (missing) throw new ForbiddenError(`Missing permission: ${missing}`);

  req.project = project;
  req.projectAccess = { role, permissions, can: (p) => permissions.has(p) };
  setContextValue('projectId', projectId);
  setContextValue('projectRole', role);
  next();
};
