import { UnauthorizedError } from '../utils/errors.js';
import { verifyAccessToken } from '../utils/tokens.js';
import { setContextValue } from '../utils/requestContext.js';
import { getAuthUser } from '../modules/auth/auth.service.js';

/**
 * Verifies the Bearer access token, loads the user + role + permissions from the database
 * (so deactivation / role changes apply immediately) and stores them on `req.user`
 * and in the request context store.
 */
export async function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    throw new UnauthorizedError('Authentication token is missing', 'TOKEN_MISSING');
  }

  let payload;
  try {
    payload = verifyAccessToken(token);
  } catch (err) {
    if (err.name === 'TokenExpiredError') throw new UnauthorizedError('Access token has expired', 'TOKEN_EXPIRED');
    throw new UnauthorizedError('Access token is invalid', 'TOKEN_INVALID');
  }

  const user = await getAuthUser(Number(payload.sub));
  if (!user) throw new UnauthorizedError('Account no longer exists', 'TOKEN_INVALID');
  if (!user.isActive) throw new UnauthorizedError('Your account has been deactivated', 'ACCOUNT_DISABLED');

  req.user = user;
  setContextValue('user', user);
  next();
}
