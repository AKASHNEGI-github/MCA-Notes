import { AppError } from '../utils/errors.js';
import { sendError } from '../utils/apiResponse.js';
import { logger } from '../utils/logger.js';
import { env } from '../config/env.js';

/** Single place where every thrown error becomes the standard error response. */
export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);

  let status = 500;
  let message = 'Internal server error';
  let code = 'INTERNAL_ERROR';
  let errors = [];

  if (err instanceof AppError) {
    ({ statusCode: status, message, code, errors } = err);
  } else if (err?.type === 'entity.parse.failed') {
    status = 400; message = 'Request body is not valid JSON'; code = 'INVALID_JSON';
  } else if (err?.type === 'entity.too.large') {
    status = 413; message = 'Request body is too large'; code = 'PAYLOAD_TOO_LARGE';
  } else if (err?.code === 'ER_DUP_ENTRY') {
    status = 409; message = 'A record with the same unique value already exists'; code = 'DUPLICATE_ENTRY';
  } else if (err?.code === 'ER_NO_REFERENCED_ROW_2') {
    status = 400; message = 'A referenced record does not exist'; code = 'INVALID_REFERENCE';
  } else {
    logger.error(`${req.method} ${req.originalUrl}`, err);
    if (!env.isProduction) message = err?.message || message;
  }

  if (status >= 500 && err instanceof AppError) logger.error(err);
  return sendError(res, { statusCode: status, message, code, errors });
}
