import { ForbiddenError, UnauthorizedError } from '../utils/errors.js';

/** Global RBAC check: the caller's global role must grant every listed permission. */
export const authorize = (...permissions) => (req, res, next) => {
  if (!req.user) throw new UnauthorizedError();
  const missing = permissions.find((p) => !req.user.permissions.has(p));
  if (missing) throw new ForbiddenError(`Missing permission: ${missing}`);
  next();
};
