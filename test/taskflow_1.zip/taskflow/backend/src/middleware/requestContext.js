import { randomUUID } from 'node:crypto';
import { runWithContext } from '../utils/requestContext.js';

/**
 * Opens the per-request context store. Mounted AFTER the body parsers so that every
 * later middleware, route handler and service shares the same store.
 */
export function requestContext(req, res, next) {
  const requestId = req.headers['x-request-id']?.toString().slice(0, 64) || randomUUID();
  res.setHeader('X-Request-Id', requestId);

  runWithContext(
    {
      requestId,
      ip: req.ip,
      userAgent: req.headers['user-agent'] || '',
      method: req.method,
      path: req.originalUrl,
      user: null,
    },
    next
  );
}
