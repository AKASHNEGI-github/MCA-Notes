import { NotFoundError } from '../utils/errors.js';

export function notFound(req) {
  throw new NotFoundError(`Route not found: ${req.method} ${req.originalUrl}`, 'ROUTE_NOT_FOUND');
}
