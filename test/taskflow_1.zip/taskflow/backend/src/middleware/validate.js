import { ValidationError } from '../utils/errors.js';

/**
 * validate({ params, query, body }) - each value is a zod schema.
 * Parsed (coerced / trimmed / defaulted) values replace the raw ones on `req`.
 */
export const validate = (schemas) => (req, res, next) => {
  const errors = [];
  const parsed = {};

  for (const location of ['params', 'query', 'body']) {
    const schema = schemas[location];
    if (!schema) continue;

    const input = location === 'body' ? req.body ?? {} : req[location];
    const result = schema.safeParse(input);

    if (result.success) {
      parsed[location] = result.data;
    } else {
      for (const issue of result.error.issues) {
        errors.push({ field: issue.path.join('.') || location, message: issue.message, location });
      }
    }
  }

  if (errors.length) throw new ValidationError(errors);

  if (parsed.params) req.params = parsed.params;
  if (parsed.body) req.body = parsed.body;
  if (parsed.query) {
    // Express 5 exposes req.query as a getter, so redefine it with the parsed value.
    Object.defineProperty(req, 'query', { value: parsed.query, writable: true, configurable: true, enumerable: true });
  }
  next();
};
