import app from './app.js';
import { env } from './config/env.js';
import { checkConnection, pool } from './config/db.js';
import { logger } from './utils/logger.js';

async function start() {
  try {
    await checkConnection();
    logger.info('MySQL connected');
  } catch (err) {
    logger.error('Could not connect to MySQL:', err.message);
    logger.error('Check DATABASE_URL / DB_* in backend/.env and run `npm run db:init` once.');
    process.exit(1);
  }

  const server = app.listen(env.port, () => logger.info(`TaskFlow API listening on http://localhost:${env.port}/api/v1`));

  const shutdown = async (signal) => {
    logger.info(`${signal} received, shutting down`);
    server.close(async () => {
      await pool.end();
      process.exit(0);
    });
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

start();
