import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { env } from './config/env.js';
import routes from './routes.js';
import { requestContext } from './middleware/requestContext.js';
import { notFound } from './middleware/notFound.js';
import { errorHandler } from './middleware/errorHandler.js';
import { logger } from './utils/logger.js';

const app = express();

app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: env.corsOrigin.split(',').map((o) => o.trim()), exposedHeaders: ['X-Request-Id'] }));
app.use(express.json({ limit: '1mb' }));

// Opened after the body parser so every later layer shares one request context.
app.use(requestContext);

app.use((req, res, next) => {
  const started = Date.now();
  res.on('finish', () => logger.info(`${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - started}ms`));
  next();
});

app.use('/api/v1', routes);
app.use(notFound);
app.use(errorHandler);

export default app;
