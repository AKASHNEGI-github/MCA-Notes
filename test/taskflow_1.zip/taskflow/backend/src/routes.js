import { Router } from 'express';
import { authenticate } from './middleware/authenticate.js';
import authRouter from './modules/auth/auth.router.js';
import usersRouter from './modules/users/users.router.js';
import adminRouter from './modules/admin/admin.router.js';
import projectsRouter from './modules/projects/projects.router.js';
import membersRouter from './modules/members/members.router.js';
import tasksRouter, { myTasksRouter } from './modules/tasks/tasks.router.js';
import commentsRouter from './modules/comments/comments.router.js';
import auditRouter from './modules/audit/audit.router.js';
import dashboardRouter from './modules/dashboard/dashboard.router.js';

const router = Router();

router.get('/health', (req, res) => res.json({ success: true, message: 'TaskFlow API is running', data: { time: new Date().toISOString() }, meta: null }));

// Auth decides per route which endpoints are public.
router.use('/auth', authRouter);

// Everything below requires a valid access token.
router.use(authenticate);
router.use('/users', usersRouter);
router.use('/admin', adminRouter);
router.use('/dashboard', dashboardRouter);
router.use('/tasks', myTasksRouter);
router.use('/projects', projectsRouter);
router.use('/projects/:projectId/members', membersRouter);
router.use('/projects/:projectId/tasks', tasksRouter);
router.use('/projects/:projectId/tasks/:taskId/comments', commentsRouter);
router.use('/projects/:projectId/activity', auditRouter);

export default router;
