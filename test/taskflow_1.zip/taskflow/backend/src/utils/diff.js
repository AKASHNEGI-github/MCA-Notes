/** Compare two plain objects on the given fields -> { field: { from, to } } for changed ones. */
export function diffFields(before, after, fields) {
  const changes = {};
  for (const field of fields) {
    if (after[field] === undefined) continue;
    const a = before[field] ?? null;
    const b = after[field] ?? null;
    if (String(a) !== String(b)) changes[field] = { from: a, to: b };
  }
  return changes;
}
