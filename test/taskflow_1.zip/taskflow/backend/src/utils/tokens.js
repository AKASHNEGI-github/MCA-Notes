import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

export const signAccessToken = (userId) =>
  jwt.sign({ sub: String(userId) }, env.auth.accessSecret, { expiresIn: env.auth.accessTtl });

/** Throws jsonwebtoken errors (TokenExpiredError, JsonWebTokenError) - callers map them. */
export const verifyAccessToken = (token) => jwt.verify(token, env.auth.accessSecret);

/** Refresh tokens are opaque random strings; only their sha256 hash is stored. */
export const generateRefreshToken = () => crypto.randomBytes(48).toString('hex');
export const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');
