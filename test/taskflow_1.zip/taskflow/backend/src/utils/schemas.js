import { z } from 'zod';

// Friendlier default message for missing required fields.
z.config({
  customError: (issue) => {
    if (issue.code === 'invalid_type' && issue.input === undefined) return 'This field is required';
    return undefined;
  },
});

export const idSchema = z.coerce
  .number({ error: 'Must be a valid id' })
  .int('Must be a valid id')
  .positive('Must be a valid id');

export const nameSchema = z.string().trim().min(2, 'Name must be at least 2 characters').max(100, 'Name is too long');

export const emailSchema = z.string().trim().toLowerCase().max(255).pipe(z.email('Enter a valid email address'));

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(72, 'Password must be at most 72 characters')
  .regex(/[A-Za-z]/, 'Password must contain a letter')
  .regex(/[0-9]/, 'Password must contain a number');

export const dateSchema = z.iso.date('Use the format YYYY-MM-DD');

export const pageQuery = {
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(10),
};

export const booleanQuery = z.enum(['true', 'false']).transform((v) => v === 'true');
