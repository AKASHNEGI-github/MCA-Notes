import { query } from '../config/db.js';

/** Permission codes granted to a role. */
export async function getRolePermissions(roleId, conn = null) {
  const rows = await query(
    `SELECT p.code
       FROM role_permissions rp
       JOIN permissions p ON p.id = rp.permission_id AND p.deleted_at IS NULL
      WHERE rp.role_id = ? AND rp.deleted_at IS NULL`,
    [roleId],
    conn
  );
  return new Set(rows.map((r) => r.code));
}

/** Every permission code of a scope (used for admins, who can do everything in a project). */
export async function getScopePermissions(scope) {
  const rows = await query('SELECT code FROM permissions WHERE scope = ? AND deleted_at IS NULL', [scope]);
  return new Set(rows.map((r) => r.code));
}
