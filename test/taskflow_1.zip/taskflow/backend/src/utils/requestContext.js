import { AsyncLocalStorage } from 'node:async_hooks';

/**
 * Request context store.
 * One Map per request lives in AsyncLocalStorage, so any code running because of that
 * request (services, SQL helpers, audit logger) can read who is calling and which
 * request this is - without passing `user` through every function signature.
 */
const storage = new AsyncLocalStorage();

export const runWithContext = (initial, fn) => storage.run(new Map(Object.entries(initial)), fn);

export const getContext = () => storage.getStore();

export function setContextValue(key, value) {
  const store = storage.getStore();
  if (store) store.set(key, value);
}

export const getContextValue = (key) => storage.getStore()?.get(key);

// Convenience accessors used all over the services
export const getCurrentUser = () => getContextValue('user') ?? null;
export const getCurrentUserId = () => getContextValue('user')?.id ?? null;
export const getRequestId = () => getContextValue('requestId') ?? null;
