/** Row -> API shape mappers (snake_case SQL columns -> camelCase JSON). */

export const mapUser = (row) => ({
  id: row.id,
  name: row.name,
  email: row.email,
  isActive: Boolean(row.is_active),
  lastLoginAt: row.last_login_at ?? null,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
  role: { id: row.role_id, name: row.role_name },
});

export const mapUserBrief = (id, name) => (id == null ? null : { id, name });
