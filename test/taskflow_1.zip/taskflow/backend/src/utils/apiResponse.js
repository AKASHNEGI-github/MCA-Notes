/**
 * Standard API response envelopes.
 *   success: { success: true,  message, data, meta }
 *   error:   { success: false, message, code, errors }
 */
export function sendSuccess(res, { statusCode = 200, message = 'Success', data = null, meta = null } = {}) {
  return res.status(statusCode).json({ success: true, message, data, meta });
}

export const sendCreated = (res, { message = 'Created successfully', data = null } = {}) =>
  sendSuccess(res, { statusCode: 201, message, data });

export function sendError(res, { statusCode = 500, message = 'Something went wrong', code = 'INTERNAL_ERROR', errors = [] } = {}) {
  return res.status(statusCode).json({ success: false, message, code, errors });
}
