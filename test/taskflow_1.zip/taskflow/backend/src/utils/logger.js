import { getRequestId } from './requestContext.js';

const stamp = (level, args) => {
  const reqId = getRequestId();
  return [`${new Date().toISOString()} ${level}${reqId ? ` [${reqId.slice(0, 8)}]` : ''}`, ...args];
};

export const logger = {
  info: (...args) => console.log(...stamp('INFO ', args)),
  warn: (...args) => console.warn(...stamp('WARN ', args)),
  error: (...args) => console.error(...stamp('ERROR', args)),
};
