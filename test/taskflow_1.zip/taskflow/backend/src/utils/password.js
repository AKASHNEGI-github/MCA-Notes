import bcrypt from 'bcryptjs';
import { env } from '../config/env.js';

export const hashPassword = (plain) => bcrypt.hash(plain, env.auth.bcryptRounds);
export const comparePassword = (plain, hash) => bcrypt.compare(plain, hash);

// Compared against when the email is unknown, so "no such user" and "wrong password"
// take about the same time (prevents user enumeration through response timing).
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', env.auth.bcryptRounds);
export const fakeCompare = (plain) => bcrypt.compare(plain, DUMMY_HASH);
