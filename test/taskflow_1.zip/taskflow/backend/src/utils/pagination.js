export const DEFAULT_LIMIT = 10;
export const MAX_LIMIT = 100;

/** Turn validated `page` / `limit` into SQL LIMIT/OFFSET numbers. */
export function getPagination({ page = 1, limit = DEFAULT_LIMIT } = {}) {
  const safeLimit = Math.min(Math.max(Number(limit) || DEFAULT_LIMIT, 1), MAX_LIMIT);
  const safePage = Math.max(Number(page) || 1, 1);
  return { page: safePage, limit: safeLimit, offset: (safePage - 1) * safeLimit };
}

export function buildMeta({ page, limit, total }) {
  const totalPages = Math.max(Math.ceil(total / limit), 1);
  return { page, limit, total, totalPages, hasNext: page < totalPages, hasPrev: page > 1 };
}
