/**
 * One-time database setup: creates the database (local mode), runs schema.sql and seed.sql,
 * and creates the first admin user from ADMIN_* in .env.
 * Safe to run again - everything is idempotent.
 *
 *   npm run db:init
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mysql from 'mysql2/promise';
import { env } from '../src/config/env.js';
import { hashPassword } from '../src/utils/password.js';

const sqlDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../database/mysql');

async function connect() {
  if (env.db.url) {
    return mysql.createConnection({ uri: env.db.url, multipleStatements: true });
  }

  // Local mode: make sure the database exists first.
  const bootstrap = await mysql.createConnection({
    host: env.db.host, port: env.db.port, user: env.db.user, password: env.db.password,
  });
  await bootstrap.query(`CREATE DATABASE IF NOT EXISTS \`${env.db.name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await bootstrap.end();

  return mysql.createConnection({
    host: env.db.host, port: env.db.port, user: env.db.user, password: env.db.password,
    database: env.db.name, multipleStatements: true,
  });
}

async function main() {
  const conn = await connect();
  try {
    console.log('Creating tables...');
    await conn.query(await fs.readFile(path.join(sqlDir, 'schema.sql'), 'utf8'));

    console.log('Seeding roles and permissions...');
    await conn.query(await fs.readFile(path.join(sqlDir, 'seed.sql'), 'utf8'));

    const [existing] = await conn.query('SELECT id FROM users WHERE email = ?', [env.admin.email]);
    if (existing.length) {
      console.log(`Admin ${env.admin.email} already exists - left untouched.`);
    } else {
      const [[role]] = await conn.query("SELECT id FROM roles WHERE scope = 'GLOBAL' AND name = 'ADMIN'");
      const [created] = await conn.query('INSERT INTO users (name, email, role_id) VALUES (?, ?, ?)', [
        env.admin.name, env.admin.email, role.id,
      ]);
      await conn.query('INSERT INTO passwords (user_id, password_hash) VALUES (?, ?)', [
        created.insertId, await hashPassword(env.admin.password),
      ]);
      console.log(`Admin created: ${env.admin.email} / ${env.admin.password}  (change this password after first login)`);
    }
    console.log('Database ready.');
  } finally {
    await conn.end();
  }
}

main().catch((err) => {
  console.error('db:init failed:', err.message);
  process.exit(1);
});
